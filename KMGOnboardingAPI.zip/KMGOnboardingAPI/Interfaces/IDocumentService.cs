﻿using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.DTOs.ForService;

namespace KMGOnboardingAPI.Interfaces
{
    public interface IDocumentService
    {
        Task<List<DocumentDto>> GetDocumentsAsync(string? category = null, string? department = null, bool publicOnly = false);
        Task<DocumentDto?> GetByIdAsync(Guid id);
        Task<DocumentDto> UploadAsync(UploadDocumentRequest request, Guid uploadedById);
        Task<string> GenerateAiSummaryAsync(Guid documentId);
    }
}
