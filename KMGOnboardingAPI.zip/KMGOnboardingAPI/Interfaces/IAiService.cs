﻿using KMGOnboardingAPI.DTOs.AI;

namespace KMGOnboardingAPI.Interfaces
{
    public interface IAiService
    {
        Task<AiChatResponse> ChatAsync(AiChatRequest request, string? employeeContext = null);
        Task<AiInsightDto> GenerateInsightAsync(Guid employeeId);
        Task<string> SummarizeDocumentAsync(string documentContent);
        Task<string> GeneratePersonalizedWelcomeAsync(Guid employeeId);
        Task<List<string>> SuggestTasksAsync(string department, string position);
        Task<string> TranslateToKazakhAsync(string text);
    }
}
