﻿using KMGOnboardingAPI.DTOs;

namespace KMGOnboardingAPI.Interfaces
{
    public interface IMeetingService
    {
        Task<List<MeetingDto>> GetForEmployeeAsync(Guid employeeId);
        Task<MeetingDto> CreateAsync(CreateMeetingRequest request, Guid organizerId);
        Task RespondAsync(Guid meetingId, Guid employeeId, bool accepted);
    }
}
