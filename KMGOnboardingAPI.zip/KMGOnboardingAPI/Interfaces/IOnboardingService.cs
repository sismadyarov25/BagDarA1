﻿using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.DTOs.ForService;

namespace KMGOnboardingAPI.Interfaces
{
    public interface IOnboardingService
    {
        Task<List<TaskAssignmentDto>> GetEmployeeTasksAsync(Guid employeeId);
        Task<TaskAssignmentDto> UpdateTaskStatusAsync(Guid assignmentId, UpdateTaskStatusRequest request);
        Task<OnboardingPlanDto?> GetPlanAsync(Guid planId);
        Task<OnboardingPlanDto> CreatePlanAsync(CreateOnboardingPlanRequest request);
        Task AssignPlanToEmployeeAsync(Guid planId, Guid employeeId);
        Task<List<CheckpointDto>> GetCheckpointsAsync(Guid employeeId);
        Task<CheckpointDto> CompleteCheckpointAsync(Guid checkpointId, CompleteCheckpointRequest request);
        Task<int> CalculateProgressAsync(Guid employeeId);
    }
}
