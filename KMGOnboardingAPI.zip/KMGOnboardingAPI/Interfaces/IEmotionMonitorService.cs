﻿using KMGOnboardingAPI.DTOs;

namespace KMGOnboardingAPI.Interfaces
{
    public interface IEmotionMonitorService
    {
        Task<EmotionSnapshotDto> AnalyzeEmployeeAsync(Guid employeeId);
        Task<EmotionDashboardDto> GetHrDashboardAsync();
        Task<List<EmotionSnapshotDto>> GetEmployeeHistoryAsync(Guid employeeId, int days = 30);
        Task RunScheduledAnalysisAsync();
    }
}
