﻿using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.DTOs.ForService;

namespace KMGOnboardingAPI.Interfaces
{
    public interface IEmployeeService
    {
        Task<EmployeeDto?> GetByIdAsync(Guid id);
        Task<List<EmployeeSummaryDto>> GetAllAsync(string? department = null, string? search = null);
        Task<EmployeeDto> UpdateAsync(Guid id, UpdateEmployeeRequest request);
        Task<DashboardDto> GetDashboardAsync(Guid requestingEmployeeId);
        Task<List<EmployeeSummaryDto>> GetAtRiskEmployeesAsync();
    }
}
