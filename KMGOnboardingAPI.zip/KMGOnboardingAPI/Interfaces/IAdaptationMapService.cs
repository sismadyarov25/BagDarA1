﻿using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.DTOs.Week;

namespace KMGOnboardingAPI.Interfaces
{
    public interface IAdaptationMapService
    {
        Task<AdaptationMapDto> GetMapAsync(Guid employeeId);
        Task<AdaptationMapDto> InitializeMapAsync(Guid employeeId);
        Task<MilestoneDto> CompleteMilestoneAsync(Guid milestoneId, Guid requestingEmployeeId);
        Task<WeeklyPlanDto> GetOrGenerateWeeklyPlanAsync(Guid employeeId, int? weekNumber = null);
        Task<WeeklyPlanDto> AcknowledgeWeeklyPlanAsync(Guid planId, Guid employeeId);
        Task RunWeeklyPlanGenerationAsync();
    }
}
