﻿using KMGOnboardingAPI.DTOs.Language;

namespace KMGOnboardingAPI.Interfaces
{
    public interface ITranslationService
    {
        Task<TranslatedMessageDto> TranslateMessageAsync(Guid messageId, string targetLanguage, Guid requestingEmployeeId);
        Task<List<TranslatedMessageDto>> BulkTranslateAsync(List<Guid> messageIds, string targetLanguage, Guid requestingEmployeeId);
        Task SetEmployeeLanguagePreferenceAsync(Guid employeeId, string language);
        Task<string?> GetEmployeeLanguagePreferenceAsync(Guid employeeId);
        Task<string> DetectLanguageAsync(string text);
    }
}
