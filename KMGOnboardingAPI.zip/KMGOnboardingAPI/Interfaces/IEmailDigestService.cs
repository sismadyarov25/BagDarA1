﻿namespace KMGOnboardingAPI.Interfaces
{
    public interface IEmailDigestService
    {
        Task SendWeeklyHrDigestAsync();
        Task SendBurnoutAlertEmailAsync(Guid employeeId, double burnoutRisk, string signals);
    }
}
