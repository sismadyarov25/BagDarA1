﻿using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.DTOs.ForService;

namespace KMGOnboardingAPI.Interfaces
{
    public interface IChatService
    {
        Task<List<ChatRoomDto>> GetRoomsForEmployeeAsync(Guid employeeId);
        Task<List<ChatMessageDto>> GetMessagesAsync(Guid roomId, int page, int pageSize, Guid requestingEmployeeId);
        Task<ChatMessageDto> SendMessageAsync(Guid roomId, SendMessageRequest request, Guid senderId);
        Task<ChatMessageDto?> EditMessageAsync(Guid messageId, string content, Guid requestingEmployeeId);
        Task DeleteMessageAsync(Guid messageId, Guid requestingEmployeeId);
        Task<ChatRoomDto> CreateRoomAsync(CreateRoomRequest request, Guid creatorId);
        Task AddReactionAsync(Guid messageId, string emoji, Guid employeeId);
    }
}
