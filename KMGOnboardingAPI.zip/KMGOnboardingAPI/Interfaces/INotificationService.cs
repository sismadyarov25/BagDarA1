﻿using KMGOnboardingAPI.DTOs;

namespace KMGOnboardingAPI.Interfaces
{
    public interface INotificationService
    {
        Task<List<NotificationDto>> GetForEmployeeAsync(Guid employeeId, bool unreadOnly = false);
        Task MarkAsReadAsync(Guid notificationId);
        Task MarkAllAsReadAsync(Guid employeeId);
        Task SendAsync(Guid employeeId, string title, string body, Models.Enums.NotificationType type, string? actionUrl = null);
        Task SendToAllAsync(string title, string body, Models.Enums.NotificationType type);
    }
}
