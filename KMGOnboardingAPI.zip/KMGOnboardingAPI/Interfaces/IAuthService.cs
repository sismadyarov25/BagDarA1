﻿using KMGOnboardingAPI.DTOs.Register;

namespace KMGOnboardingAPI.Interfaces
{
    public interface IAuthService
    {
        Task<AuthResponse> LoginAsync(LoginRequest request);
        Task<AuthResponse> RegisterAsync(RegisterRequest request);
        Task<AuthResponse> RefreshTokenAsync(string refreshToken);
        Task RevokeTokenAsync(Guid employeeId);
    }
}
