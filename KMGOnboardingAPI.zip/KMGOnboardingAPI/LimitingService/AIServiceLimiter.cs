﻿using Microsoft.AspNetCore.RateLimiting;

namespace KMGOnboardingAPI.LimitingService
{
    //public class AIServiceLimiter : IRateLimiterPolicy<Guid>
    //{
    //    private Func<OnRejectedContext, CancellationToken, ValueTask> _onRejectedContext;
    //    private readonly 
    //}
}
