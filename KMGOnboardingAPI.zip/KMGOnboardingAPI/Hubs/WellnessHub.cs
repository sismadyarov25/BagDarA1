﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Text.RegularExpressions;

namespace KMGOnboardingAPI.Hubs
{
    [Authorize]
    public class WellnessHub : Hub
    {
        private readonly ILogger<WellnessHub> _logger;

        public WellnessHub(ILogger<WellnessHub> logger)
        {
            _logger = logger;
        }

        public override async Task OnConnectedAsync()
        {
            var employeeId = Context.User?.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (employeeId != null)
                await Groups.AddToGroupAsync(Context.ConnectionId, $"wellness_{employeeId}");
            await base.OnConnectedAsync();
        }

        public async Task PushWellnessUpdate(string employeeId, string tone, double burnoutRisk, string advice)
        {
            await Clients.Group($"wellness_{employeeId}").SendAsync("WellnessUpdate", new
            {
                tone,
                burnoutRisk,
                advice,
                timestamp = DateTime.UtcNow
            });
        }
    }
}
