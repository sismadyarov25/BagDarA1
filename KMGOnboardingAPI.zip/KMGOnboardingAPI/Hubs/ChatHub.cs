﻿using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.Interfaces;
using KMGOnboardingAPI.Models.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Text.RegularExpressions;

namespace KMGOnboardingAPI.Hubs
{
    [Authorize]
    public class ChatHub : Hub
    {
        private readonly IChatService _chatService;
        private readonly ILogger<ChatHub> _logger;

        public ChatHub(IChatService chatService, ILogger<ChatHub> logger)
        {
            _chatService = chatService;
            _logger = logger;
        }

        public override async Task OnConnectedAsync()
        {
            var employeeId = GetEmployeeId();
            _logger.LogInformation("Employee {Id} connected to chat", employeeId);

            var rooms = await _chatService.GetRoomsForEmployeeAsync(employeeId);
            foreach (var room in rooms)
                await Groups.AddToGroupAsync(Context.ConnectionId, room.Id.ToString());

            await base.OnConnectedAsync();
        }

        public override async Task OnDisconnectedAsync(Exception? exception)
        {
            _logger.LogInformation("Employee {Id} disconnected from chat", GetEmployeeId());
            await base.OnDisconnectedAsync(exception);
        }

        public async Task SendMessage(Guid roomId, string content, Guid? replyToId = null)
        {
            var senderId = GetEmployeeId();
            var request = new SendMessageRequest(content, MessageType.Text, replyToId);
            var message = await _chatService.SendMessageAsync(roomId, request, senderId);
            await Clients.Group(roomId.ToString()).SendAsync("ReceiveMessage", message);
        }

        public async Task EditMessage(Guid messageId, string newContent)
        {
            var requesterId = GetEmployeeId();
            var updated = await _chatService.EditMessageAsync(messageId, newContent, requesterId);
            if (updated != null)
                await Clients.Group(updated.RoomId.ToString()).SendAsync("MessageEdited", updated);
        }

        public async Task DeleteMessage(Guid messageId, Guid roomId)
        {
            var requesterId = GetEmployeeId();
            await _chatService.DeleteMessageAsync(messageId, requesterId);
            await Clients.Group(roomId.ToString()).SendAsync("MessageDeleted", messageId);
        }

        public async Task AddReaction(Guid messageId, Guid roomId, string emoji)
        {
            var employeeId = GetEmployeeId();
            await _chatService.AddReactionAsync(messageId, emoji, employeeId);
            await Clients.Group(roomId.ToString()).SendAsync("ReactionUpdated", new { messageId, emoji, employeeId });
        }

        public async Task StartTyping(Guid roomId)
        {
            var employeeId = GetEmployeeId();
            await Clients.OthersInGroup(roomId.ToString()).SendAsync("UserTyping", new { roomId, employeeId });
        }

        public async Task StopTyping(Guid roomId)
        {
            var employeeId = GetEmployeeId();
            await Clients.OthersInGroup(roomId.ToString()).SendAsync("UserStoppedTyping", new { roomId, employeeId });
        }

        public async Task JoinRoom(Guid roomId)
        {
            await Groups.AddToGroupAsync(Context.ConnectionId, roomId.ToString());
        }

        public async Task LeaveRoom(Guid roomId)
        {
            await Groups.RemoveFromGroupAsync(Context.ConnectionId, roomId.ToString());
        }

        public async Task RequestTranslation(Guid messageId, string targetLanguage)
        {
            var employeeId = GetEmployeeId();
            await Clients.Caller.SendAsync("TranslationRequested", new { messageId, targetLanguage, status = "processing" });
        }

        private Guid GetEmployeeId()
        {
            var claim = Context.User?.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            return Guid.TryParse(claim, out var id) ? id : throw new HubException("Unauthorized");
        }
    }
}
