﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Text.RegularExpressions;

namespace KMGOnboardingAPI.Hubs
{
    [Authorize]
    public class NotificationHub : Hub
    {
        private readonly ILogger<NotificationHub> _logger;

        public NotificationHub(ILogger<NotificationHub> logger)
        {
            _logger = logger;
        }

        public override async Task OnConnectedAsync()
        {
            var employeeId = Context.User?.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (employeeId != null)
            {
                await Groups.AddToGroupAsync(Context.ConnectionId, employeeId);
                await Groups.AddToGroupAsync(Context.ConnectionId, "all_employees");
            }
            await base.OnConnectedAsync();
        }

        public async Task BroadcastEmotionAlert(string employeeId, string tone, double burnoutRisk)
        {
            await Clients.Group("hr_managers").SendAsync("EmotionAlert", new
            {
                employeeId,
                tone,
                burnoutRisk,
                timestamp = DateTime.UtcNow
            });
        }

        public async Task JoinHrGroup()
        {
            await Groups.AddToGroupAsync(Context.ConnectionId, "hr_managers");
        }
    }
}
