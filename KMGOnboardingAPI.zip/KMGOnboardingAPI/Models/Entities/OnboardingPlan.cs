﻿using KMGOnboardingAPI.Models.Entities.Base;

namespace KMGOnboardingAPI.Models.Entities
{
    public class OnboardingPlan : BaseEntity
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Department { get; set; } = string.Empty;
        public string Position { get; set; } = string.Empty;
        public int DurationDays { get; set; } = 90;
        public bool IsTemplate { get; set; } = false;

        public ICollection<OnboardingTask> Tasks { get; set; } = new List<OnboardingTask>();
    }
}
