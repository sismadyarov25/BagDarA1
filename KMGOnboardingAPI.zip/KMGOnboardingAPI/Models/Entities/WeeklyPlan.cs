﻿using KMGOnboardingAPI.Models.Entities.Base;

namespace KMGOnboardingAPI.Models.Entities
{
    public class WeeklyPlan : BaseEntity
    {
        public int WeekNumber { get; set; }
        public string AiGeneratedPlan { get; set; } = string.Empty;
        public string Focus { get; set; } = string.Empty;
        public List<string>? Goals { get; set; }
        public DateTime GeneratedAt { get; set; } = DateTime.UtcNow;
        public bool IsAcknowledged { get; set; } = false;

        public Guid EmployeeId { get; set; }
        public Employee Employee { get; set; } = null!;
    }
}
