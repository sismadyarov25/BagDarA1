﻿using KMGOnboardingAPI.Models.Entities.Base;

namespace KMGOnboardingAPI.Models.Entities
{
    public class MeetingParticipant : BaseEntity
    {
        public bool IsAccepted { get; set; } = false;

        public Guid MeetingId { get; set; }
        public Meeting Meeting { get; set; } = null!;
        public Guid EmployeeId { get; set; }
        public Employee Employee { get; set; } = null!;
    }
}
