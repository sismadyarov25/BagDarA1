﻿using KMGOnboardingAPI.Models.Entities.Base;

namespace KMGOnboardingAPI.Models.Entities
{
    public class AiInsight : BaseEntity
    {
        public string StrengthsAnalysis { get; set; } = string.Empty;
        public string RiskFactors { get; set; } = string.Empty;
        public string Recommendations { get; set; } = string.Empty;
        public double EngagementScore { get; set; }
        public double RetentionRisk { get; set; }
        public DateTime LastAnalyzedAt { get; set; } = DateTime.UtcNow;

        public Guid EmployeeId { get; set; }
        public Employee Employee { get; set; } = null!;
    }
}
