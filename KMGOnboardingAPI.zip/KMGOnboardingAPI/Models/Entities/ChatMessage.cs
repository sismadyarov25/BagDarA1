﻿using KMGOnboardingAPI.Models.Entities.Base;
using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.Models.Entities
{
    public class ChatMessage : BaseEntity
    {
        public string Content { get; set; } = string.Empty;
        public MessageType MessageType { get; set; } = MessageType.Text;
        public bool IsEdited { get; set; } = false;

        public Guid RoomId { get; set; }
        public ChatRoom Room { get; set; } = null!;
        public Guid SenderId { get; set; }
        public Employee Sender { get; set; } = null!;

        public Guid? ReplyToId { get; set; }
        public ChatMessage? ReplyTo { get; set; }
        public ICollection<MessageReaction> Reactions { get; set; } = new List<MessageReaction>();
    }
}
