﻿using KMGOnboardingAPI.Models.Entities.Base;

namespace KMGOnboardingAPI.Models.Entities
{
    public class OnboardingCheckpoint : BaseEntity
    {
        public string Title { get; set; } = string.Empty;
        public int WeekNumber { get; set; }
        public bool IsCompleted { get; set; } = false;
        public DateTime? CompletedAt { get; set; }
        public string? HrFeedback { get; set; }
        public int? SatisfactionScore { get; set; }

        public Guid EmployeeId { get; set; }
        public Employee Employee { get; set; } = null!;
    }
}
