﻿using KMGOnboardingAPI.Models.Entities.Base;

namespace KMGOnboardingAPI.Models.Entities
{
    public class ChatRoomMember : BaseEntity
    {
        public DateTime JoinedAt { get; set; } = DateTime.UtcNow;

        public Guid RoomId { get; set; }
        public ChatRoom Room { get; set; } = null!;
        public Guid EmployeeId { get; set; }
        public Employee Employee { get; set; } = null!;
    }
}
