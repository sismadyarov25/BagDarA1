﻿using KMGOnboardingAPI.Models.Entities.Base;
using Microsoft.AspNetCore.Identity;
using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.Models.Entities
{
    public class Employee : BaseEntity
    {
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public string Position { get; set; } = string.Empty;
        public string Department { get; set; } = string.Empty;
        public DateTime HireDate { get; set; }
        public string? AvatarUrl { get; set; }
        public string? PhoneNumber { get; set; }
        public string? ManagerId { get; set; }
        public EmployeeRole Role { get; set; } = EmployeeRole.Employee;
        public OnboardingStatus OnboardingStatus { get; set; } = OnboardingStatus.NotStarted;
        public int OnboardingProgress { get; set; } = 0;
        public string? RefreshToken { get; set; }
        public DateTime? RefreshTokenExpiry { get; set; }

        public ICollection<TaskAssignment> TaskAssignments { get; set; } = new List<TaskAssignment>();
        public ICollection<OnboardingCheckpoint> Checkpoints { get; set; } = new List<OnboardingCheckpoint>();
        public ICollection<ChatMessage> SentMessages { get; set; } = new List<ChatMessage>();
        public ICollection<Document> Documents { get; set; } = new List<Document>();
        public ICollection<Notification> Notifications { get; set; } = new List<Notification>();
        public ICollection<MeetingParticipant> Meetings { get; set; } = new List<MeetingParticipant>();
        public AiInsight? AiInsight { get; set; }
    }
}
