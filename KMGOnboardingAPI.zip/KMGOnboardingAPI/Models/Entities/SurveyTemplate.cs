﻿using KMGOnboardingAPI.Models.Entities.Base;

namespace KMGOnboardingAPI.Models.Entities
{
    public class SurveyTemplate : BaseEntity
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public int WeekTrigger { get; set; }

        public ICollection<SurveyQuestion> Questions { get; set; } = new List<SurveyQuestion>();
    }
}
