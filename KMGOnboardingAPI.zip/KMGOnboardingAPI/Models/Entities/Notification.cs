﻿using KMGOnboardingAPI.Models.Entities.Base;
using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.Models.Entities
{
    public class Notification : BaseEntity
    {
        public string Title { get; set; } = string.Empty;
        public string Body { get; set; } = string.Empty;
        public NotificationType Type { get; set; }
        public bool IsRead { get; set; } = false;
        public string? ActionUrl { get; set; }
        public DateTime? ReadAt { get; set; }

        public Guid EmployeeId { get; set; }
        public Employee Employee { get; set; } = null!;
    }
}
