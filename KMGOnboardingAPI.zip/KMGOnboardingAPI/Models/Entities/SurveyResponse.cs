﻿using KMGOnboardingAPI.Models.Entities.Base;

namespace KMGOnboardingAPI.Models.Entities
{
    public class SurveyResponse : BaseEntity
    {
        public string Answer { get; set; } = string.Empty;

        public Guid QuestionId { get; set; }
        public SurveyQuestion Question { get; set; } = null!;
        public Guid EmployeeId { get; set; }
    }
}
