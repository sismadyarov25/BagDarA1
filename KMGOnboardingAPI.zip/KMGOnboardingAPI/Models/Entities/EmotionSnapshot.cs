﻿using KMGOnboardingAPI.Models.Entities.Base;
using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.Models.Entities
{
    public class EmotionSnapshot : BaseEntity
    {
        public EmotionTone OverallTone { get; set; }
        public double BurnoutRisk { get; set; }
        public double StressLevel { get; set; }
        public double EngagementLevel { get; set; }
        public string Signals { get; set; } = string.Empty;
        public string AiAdvice { get; set; } = string.Empty;
        public bool HrAlertSent { get; set; } = false;
        public int MessagesAnalyzed { get; set; }
        public int TaskNotesAnalyzed { get; set; }
        public DateTime WindowStart { get; set; }
        public DateTime WindowEnd { get; set; }

        public Guid EmployeeId { get; set; }
        public Employee Employee { get; set; } = null!;
    }
}
