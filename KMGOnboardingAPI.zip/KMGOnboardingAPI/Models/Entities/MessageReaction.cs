﻿using KMGOnboardingAPI.Models.Entities.Base;

namespace KMGOnboardingAPI.Models.Entities
{
    public class MessageReaction : BaseEntity
    {
        public string Emoji { get; set; } = string.Empty;

        public Guid MessageId { get; set; }
        public ChatMessage Message { get; set; } = null!;
        public Guid EmployeeId { get; set; }
    }
}
