﻿using KMGOnboardingAPI.Models.Entities.Base;
using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.Models.Entities
{
    public class Document : BaseEntity
    {
        public string Title { get; set; } = string.Empty;
        public string FileName { get; set; } = string.Empty;
        public string FileUrl { get; set; } = string.Empty;
        public long FileSizeBytes { get; set; }
        public string ContentType { get; set; } = string.Empty;
        public DocumentCategory Category { get; set; }
        public string? Department { get; set; }
        public bool IsPublic { get; set; } = false;
        public string? AiSummary { get; set; }
        public int DownloadCount { get; set; } = 0;

        public Guid? UploadedById { get; set; }
        public Employee? UploadedBy { get; set; }
    }
}
