﻿using KMGOnboardingAPI.Models.Entities.Base;
using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.Models.Entities
{
    public class TaskAssignment : BaseEntity
    {
        public AssignmentStatus Status { get; set; } = AssignmentStatus.Pending;
        public DateTime? CompletedAt { get; set; }
        public string? Notes { get; set; }
        public int? Score { get; set; }

        public Guid EmployeeId { get; set; }
        public Employee Employee { get; set; } = null!;
        public Guid TaskId { get; set; }
        public OnboardingTask Task { get; set; } = null!;
    }
}
