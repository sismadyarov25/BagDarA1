﻿using KMGOnboardingAPI.Models.Entities.Base;
using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.Models.Entities
{
    public class OnboardingTask : BaseEntity
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public TaskCategory Category { get; set; }
        public int DayNumber { get; set; }
        public int EstimatedMinutes { get; set; }
        public int Priority { get; set; } = 1;
        public bool IsRequired { get; set; }
        public string? ResourceUrl { get; set; }
        
        public Guid OnboardingPlanId { get; set; }
        public OnboardingPlan OnboardingPlan { get; set; } = null!;
        public ICollection<TaskAssignment> Assignments { get; set; } = new List<TaskAssignment>();
    }
}
