﻿using KMGOnboardingAPI.Models.Entities.Base;
using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.Models.Entities
{
    public class ChatRoom : BaseEntity
    {
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
        public RoomType RoomType { get; set; } = RoomType.General;

        public ICollection<ChatMessage> Messages { get; set; } = new List<ChatMessage>();
        public ICollection<ChatRoomMember> Members { get; set; } = new List<ChatRoomMember>();
    }
}
