﻿using KMGOnboardingAPI.Models.Entities.Base;
using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.Models.Entities
{
    public class SurveyQuestion : BaseEntity
    {
        public string QuestionText { get; set; } = string.Empty;
        public QuestionType QuestionType { get; set; }
        public string? Options { get; set; }
        public int Order { get; set; }

        public Guid TemplateId { get; set; }
        public SurveyTemplate Template { get; set; } = null!;
    }
}
