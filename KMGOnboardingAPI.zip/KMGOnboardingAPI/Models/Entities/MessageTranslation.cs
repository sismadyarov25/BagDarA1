﻿using KMGOnboardingAPI.Models.Entities.Base;

namespace KMGOnboardingAPI.Models.Entities
{
    public class MessageTranslation : BaseEntity
    {
        public string TargetLanguage { get; set; } = string.Empty;
        public string TranslatedContent { get; set; } = string.Empty;
        public bool IsAutoTranslated { get; set; } = true;

        public Guid MessageId { get; set; }
        public ChatMessage Message { get; set; } = null!;
    }
}
