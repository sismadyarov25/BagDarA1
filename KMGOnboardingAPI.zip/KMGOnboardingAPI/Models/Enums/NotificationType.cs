﻿namespace KMGOnboardingAPI.Models.Enums
{
    public enum NotificationType
    {
        TaskAssigned = 0,
        TaskDue = 1,
        TaskOverdue = 2,
        MeetingScheduled = 3,
        MessageReceived = 4,
        CheckpointDue = 5,
        AiInsightReady = 6,
        SystemAnnouncement = 7
    }
}
