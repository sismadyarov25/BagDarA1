﻿namespace KMGOnboardingAPI.Models.Enums
{
    public enum EmotionTone
    {
        Positive = 0,
        Neutral = 1,
        Stressed = 2,
        Disengaged = 3,
        Burnout = 4,
        Overwhelmed = 5
    }
}
