﻿namespace KMGOnboardingAPI.Models.Enums
{
    public enum OnboardingStatus
    {
        NotStarted = 0,
        InProgress = 1,
        OnTrack = 2,
        AtRisk = 3,
        Completed = 4,
        Paused = 5,
    }
}
