﻿namespace KMGOnboardingAPI.Models.Enums
{
    public enum DocumentCategory
    {
        Policy = 0,
        Training = 1,
        Template = 2,
        Benefits = 3,
        Safety = 4,
        CompanyInfo = 5,
        TechnicalDoc = 6
    }
}
