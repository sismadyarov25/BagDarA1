﻿namespace KMGOnboardingAPI.Models.Enums
{
    public enum MilestoneType
    {
        Orientation = 0,
        SystemsSetup = 1,
        TeamIntegration = 2,
        FirstProject = 3,
        SafetyCertified = 4,
        ComplianceDone = 5,
        IndependentWork = 6,
        ProbationComplete = 7,
        Custom = 8
    }
}
