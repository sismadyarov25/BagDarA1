﻿namespace KMGOnboardingAPI.Models.Enums
{
    public enum QuestionType
    {
        Text = 0,
        Rating = 1,
        MultipleChoice = 2,
        YesNo = 3,
        Scale = 4
    }
}
