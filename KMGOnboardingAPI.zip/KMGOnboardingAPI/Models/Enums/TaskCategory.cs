﻿namespace KMGOnboardingAPI.Models.Enums
{
    public enum TaskCategory
    {
        Paperwork = 0,
        Training = 1,
        SystemAccess = 2,
        TeamIntroduction = 3,
        KnowledgeBase = 4,
        SafetyCompliance = 5,
        CorporateCulture = 6,
        TechnicalSetup = 7
    }
}
