﻿namespace KMGOnboardingAPI.Models.Enums
{
    public enum MessageType
    {
        Text = 0,
        File = 1,
        Image = 2,
        System = 3
    }
}
