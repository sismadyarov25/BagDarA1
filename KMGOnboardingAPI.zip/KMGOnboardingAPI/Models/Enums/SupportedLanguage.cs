﻿namespace KMGOnboardingAPI.Models.Enums
{
    public enum SupportedLanguage
    {
        English = 0,
        Russian = 1,
        Kazakh = 2
    }
}
