﻿namespace KMGOnboardingAPI.Models.Enums
{
    public enum RoomType
    {
        General = 0,
        Department = 1,
        Onboarding = 2,
        DirectMessage = 3,
        Announcement = 4
    }
}
