﻿namespace KMGOnboardingAPI.Models.Enums
{
    public enum AssignmentStatus
    {
        Pending = 0,
        InProgress = 1,
        Completed = 2,
        Skipped = 3,
        Overdue = 4
    }
}
