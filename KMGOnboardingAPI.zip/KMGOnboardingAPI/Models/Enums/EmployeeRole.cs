﻿namespace KMGOnboardingAPI.Models.Enums
{
    public enum EmployeeRole
    {
        Employee = 0,
        HrManager = 1,
        Manager = 2,
        Admin = 3
    }
}
