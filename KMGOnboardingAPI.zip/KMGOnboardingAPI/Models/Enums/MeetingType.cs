﻿namespace KMGOnboardingAPI.Models.Enums
{
    public enum MeetingType
    {
        OneOnOne = 0,
        TeamMeeting = 1,
        Training = 2,
        CheckIn = 3,
        Orientation = 4
    }
}
