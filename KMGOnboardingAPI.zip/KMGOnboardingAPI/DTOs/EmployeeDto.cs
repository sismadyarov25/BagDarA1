﻿using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.DTOs
{
    public record EmployeeDto(
    Guid Id,
    string FirstName,
    string LastName,
    string Email,
    string Position,
    string Department,
    DateTime HireDate,
    string? AvatarUrl,
    EmployeeRole Role,
    OnboardingStatus OnboardingStatus,
    int OnboardingProgress,
    string? PhoneNumber
);
}
