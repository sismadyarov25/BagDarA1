﻿using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.DTOs
{
    public record TaskAssignmentDto(
    Guid Id,
    OnboardingTaskDto Task,
    AssignmentStatus Status,
    DateTime? CompletedAt,
    string? Notes,
    int? Score
);
}
