﻿using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.DTOs
{
    public record CreateMeetingRequest(
    string Title,
    string? Description,
    DateTime StartTime,
    DateTime EndTime,
    string? MeetingUrl,
    string? Location,
    MeetingType MeetingType,
    List<Guid> ParticipantIds
);
}
