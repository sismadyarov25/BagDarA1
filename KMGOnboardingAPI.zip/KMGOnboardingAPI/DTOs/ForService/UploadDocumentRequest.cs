﻿using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.DTOs.ForService
{
    public record UploadDocumentRequest(
    string Title,
    string FileName,
    string FileUrl,
    long FileSizeBytes,
    string ContentType,
    DocumentCategory Category,
    string? Department,
    bool IsPublic
);
}
