﻿namespace KMGOnboardingAPI.DTOs.ForService
{
    public record CreateOnboardingPlanRequest(
    string Title,
    string Description,
    string Department,
    string Position,
    int DurationDays,
    bool IsTemplate,
    List<CreateTaskRequest> Tasks
);
}
