﻿using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.DTOs.ForService
{
    public record CreateTaskRequest(
    string Title,
    string Description,
    TaskCategory? Category,
    int DayNumber,
    int EstimatedMinutes,
    int Priority,
    bool IsRequired,
    string? ResourceUrl
);
}
