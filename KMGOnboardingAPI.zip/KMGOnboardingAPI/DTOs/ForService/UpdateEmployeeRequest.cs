﻿namespace KMGOnboardingAPI.DTOs.ForService
{
    public record UpdateEmployeeRequest(
    string? FirstName = null,
    string? LastName = null,
    string? PhoneNumber = null,
    string? AvatarUrl = null
);
}
