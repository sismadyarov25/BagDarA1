﻿namespace KMGOnboardingAPI.DTOs.ForService
{
    public record CompleteCheckpointRequest(
    string? HrFeedback,
    int? SatisfactionScore
);
}
