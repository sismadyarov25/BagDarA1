﻿using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.DTOs.ForService
{
    public record CreateRoomRequest(
    string Name,
    string? Description,
    RoomType RoomType,
    List<Guid> MemberIds
);
}
