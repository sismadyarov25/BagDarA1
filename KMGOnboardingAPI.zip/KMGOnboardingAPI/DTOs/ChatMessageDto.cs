﻿using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.DTOs
{
    public record ChatMessageDto(
    Guid Id,
    Guid RoomId,
    SenderDto Sender,
    string Content,
    MessageType MessageType,
    DateTime CreatedAt,
    bool IsEdited,
    Guid? ReplyToId,
    string? ReplyContent,
    List<ReactionDto> Reactions
);
}
