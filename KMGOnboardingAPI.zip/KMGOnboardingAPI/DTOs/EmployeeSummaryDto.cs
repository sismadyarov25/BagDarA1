﻿using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.DTOs
{
    public record EmployeeSummaryDto(
    Guid Id,
    string FullName,
    string Position,
    string Department,
    string? AvatarUrl,
    OnboardingStatus OnboardingStatus,
    int OnboardingProgress,
    int DaysOnboarding
);
}
