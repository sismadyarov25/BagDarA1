﻿using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.DTOs
{
    public record MeetingDto(
    Guid Id,
    string Title,
    string? Description,
    DateTime StartTime,
    DateTime EndTime,
    string? MeetingUrl,
    string? Location,
    MeetingType MeetingType,
    List<EmployeeDto> Participants,
    bool IsAccepted
);
}
