﻿namespace KMGOnboardingAPI.DTOs
{
    public record EmotionSnapshotDto(
     Guid Id,
     Guid EmployeeId,
     string EmployeeName,
     string OverallTone,
     double BurnoutRisk,
     double StressLevel,
     double EngagementLevel,
     List<string> Signals,
     string AiAdvice,
     bool HrAlertSent,
     int MessagesAnalyzed,
     DateTime WindowStart,
     DateTime WindowEnd,
     DateTime CreatedAt
 );
}
