﻿namespace KMGOnboardingAPI.DTOs.Language
{
    public record TranslateMessageRequest(
    Guid MessageId,
    string TargetLanguage
);
}
