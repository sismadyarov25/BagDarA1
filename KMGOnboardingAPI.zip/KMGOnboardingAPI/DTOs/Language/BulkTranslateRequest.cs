﻿namespace KMGOnboardingAPI.DTOs.Language
{
    public record BulkTranslateRequest(
    List<Guid> MessageIds,
    string TargetLanguage
);
}
