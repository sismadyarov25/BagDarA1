﻿namespace KMGOnboardingAPI.DTOs.Language
{
    public record TranslatedMessageDto(
    Guid MessageId,
    string OriginalContent,
    string TranslatedContent,
    string TargetLanguage,
    bool WasCached
);
}
