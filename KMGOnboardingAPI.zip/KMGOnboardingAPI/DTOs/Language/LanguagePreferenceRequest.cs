﻿namespace KMGOnboardingAPI.DTOs.Language
{
    public record LanguagePreferenceRequest(string Language);
}
