﻿using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.DTOs
{
    public record UpdateTaskStatusRequest(
    AssignmentStatus Status,
    string? Notes = null,
    int? Score = null
);
}
