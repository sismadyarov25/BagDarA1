﻿namespace KMGOnboardingAPI.DTOs
{
    public record EmotionDashboardDto(
    List<EmotionSnapshotDto> AtRiskEmployees,
    double TeamAverageBurnout,
    double TeamAverageEngagement,
    int TotalAlertsSent,
    Dictionary<string, int> ToneDistribution
);
}
