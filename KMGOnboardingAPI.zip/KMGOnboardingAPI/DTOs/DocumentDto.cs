﻿using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.DTOs
{
    public record DocumentDto(
    Guid Id,
    string Title,
    string FileName,
    string FileUrl,
    long FileSizeBytes,
    DocumentCategory Category,
    string? Department,
    bool IsPublic,
    string? AiSummary,
    int DownloadCount,
    DateTime CreatedAt
);
}
