﻿using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.DTOs
{
    public record SendMessageRequest(
    string Content,
    MessageType MessageType = MessageType.Text,
    Guid? ReplyToId = null
);
}
