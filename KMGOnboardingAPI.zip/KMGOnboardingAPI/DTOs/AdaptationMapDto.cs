﻿using KMGOnboardingAPI.DTOs.Week;

namespace KMGOnboardingAPI.DTOs
{
    public record AdaptationMapDto(
     Guid EmployeeId,
     string EmployeeName,
     DateTime HireDate,
     int DaysOnboarding,
     int TotalDays,
     double ProgressPercent,
     int CurrentDay,
     List<MilestoneDto> Milestones,
     WeeklyPlanDto? CurrentWeekPlan,
     string CurrentPhase,
     string NextMilestoneTitle,
     int DaysToNextMilestone
 );
}
