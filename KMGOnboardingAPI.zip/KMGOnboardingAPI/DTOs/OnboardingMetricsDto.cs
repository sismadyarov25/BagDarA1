﻿namespace KMGOnboardingAPI.DTOs
{
    public record OnboardingMetricsDto(
    double AverageCompletionDays,
    double RetentionRate,
    double SatisfactionAverage,
    Dictionary<string, int> TaskCompletionByCategory
);
}
