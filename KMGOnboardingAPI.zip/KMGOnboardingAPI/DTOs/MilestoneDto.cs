﻿namespace KMGOnboardingAPI.DTOs
{
    public record MilestoneDto(
    Guid Id,
    string Title,
    string Description,
    int DayNumber,
    string MilestoneType,
    bool IsCompleted,
    DateTime? CompletedAt,
    string? AiNote,
    int Order,
    bool IsCurrent,
    bool IsUpcoming
);
}
