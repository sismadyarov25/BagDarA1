﻿using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.DTOs
{
    public record OnboardingTaskDto(
    Guid Id,
    string Title,
    string Description,
    TaskCategory Category,
    int DayNumber,
    int EstimatedMinutes,
    int Priority,
    bool IsRequired,
    string? ResourceUrl
);
}
