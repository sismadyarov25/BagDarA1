﻿namespace KMGOnboardingAPI.DTOs
{
    public record CheckpointDto(
    Guid Id,
    string Title,
    int WeekNumber,
    bool IsCompleted,
    DateTime? CompletedAt,
    string? HrFeedback,
    int? SatisfactionScore
);
}
