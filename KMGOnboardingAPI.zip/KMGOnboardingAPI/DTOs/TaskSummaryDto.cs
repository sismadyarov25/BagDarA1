﻿using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.DTOs
{
    public record TaskSummaryDto(
    Guid Id,
    string Title,
    string Category,
    string EmployeeName,
    DateTime DueDate,
    AssignmentStatus Status
);
}
