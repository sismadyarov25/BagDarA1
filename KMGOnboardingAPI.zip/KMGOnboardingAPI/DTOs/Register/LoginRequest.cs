﻿namespace KMGOnboardingAPI.DTOs.Register
{
    public record LoginRequest(string Email, string Password);
}
