﻿namespace KMGOnboardingAPI.DTOs.Register
{
    public record AuthResponse(
    string AccessToken,
    string RefreshToken,
    DateTime ExpiresAt,
    EmployeeDto Employee
    );
}
