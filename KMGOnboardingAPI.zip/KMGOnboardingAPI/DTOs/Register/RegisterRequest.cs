﻿namespace KMGOnboardingAPI.DTOs.Register
{
    public record RegisterRequest(
    string FirstName,
    string LastName,
    string Email,
    string Password,
    string Position,
    string Department,
    DateTime HireDate,
    string? PhoneNumber = null,
    string? ManagerId = null
);
}
