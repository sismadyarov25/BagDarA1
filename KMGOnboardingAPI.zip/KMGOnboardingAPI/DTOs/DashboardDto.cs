﻿namespace KMGOnboardingAPI.DTOs
{
    public record DashboardDto(
    int TotalEmployees,
    int ActiveOnboarding,
    int CompletedThisMonth,
    int AtRiskCount,
    double AverageEngagementScore,
    List<EmployeeSummaryDto> RecentNewHires,
    List<TaskSummaryDto> OverdueTasks,
    List<NotificationDto> RecentNotifications,
    OnboardingMetricsDto Metrics
);
}
