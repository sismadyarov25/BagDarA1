﻿namespace KMGOnboardingAPI.DTOs
{
    public record OnboardingPlanDto(
    Guid Id,
    string Title,
    string Description,
    string Department,
    string Position,
    int DurationDays,
    List<OnboardingTaskDto> Tasks
);
}
