﻿namespace KMGOnboardingAPI.DTOs.AI
{
    public record AiChatRequest(string Message, List<AiChatHistory>? History = null);
}
