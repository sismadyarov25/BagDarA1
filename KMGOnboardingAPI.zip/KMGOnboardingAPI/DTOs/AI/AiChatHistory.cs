﻿namespace KMGOnboardingAPI.DTOs.AI
{
    public record AiChatHistory(string Role, string Content);
}
