﻿namespace KMGOnboardingAPI.DTOs.AI
{
    public record AiInsightDto(
    Guid EmployeeId,
    string StrengthsAnalysis,
    string RiskFactors,
    string Recommendations,
    double EngagementScore,
    double RetentionRisk,
    DateTime LastAnalyzedAt
);
}
