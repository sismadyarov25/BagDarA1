﻿namespace KMGOnboardingAPI.DTOs.AI
{
    public record AiChatResponse(string Reply, bool IsError = false);
}
