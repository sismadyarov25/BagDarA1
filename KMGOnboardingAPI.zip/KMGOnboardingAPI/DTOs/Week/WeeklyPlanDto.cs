﻿namespace KMGOnboardingAPI.DTOs.Week
{
    public record WeeklyPlanDto(
    Guid Id,
    int WeekNumber,
    string AiGeneratedPlan,
    string Focus,
    List<string> Goals,
    DateTime GeneratedAt,
    bool IsAcknowledged
);
}
