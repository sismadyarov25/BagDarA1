﻿namespace KMGOnboardingAPI.DTOs.Week
{
    public record GenerateWeeklyPlanRequest(int? WeekNumber = null);
}
