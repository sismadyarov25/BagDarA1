﻿namespace KMGOnboardingAPI.DTOs
{
    public record SenderDto(
    Guid Id,
    string FullName,
    string? AvatarUrl
);
}
