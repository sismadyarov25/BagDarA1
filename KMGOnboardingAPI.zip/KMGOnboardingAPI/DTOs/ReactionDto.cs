﻿namespace KMGOnboardingAPI.DTOs
{
    public record ReactionDto(
    string Emoji,
    int Count,
    bool ReactedByMe
);
}
