﻿using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.DTOs
{
    public record ChatRoomDto(
    Guid Id,
    string Name,
    string? Description,
    RoomType RoomType,
    int MemberCount,
    ChatMessageDto? LastMessage,
    int UnreadCount
);
}
