﻿using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.DTOs.ForService;
using KMGOnboardingAPI.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace KMGOnboardingAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class OnboardingController : ControllerBase
    {
        private readonly IOnboardingService _onboarding;

        public OnboardingController(IOnboardingService onboarding) => _onboarding = onboarding;

        [HttpGet("tasks")]
        public async Task<ActionResult<List<TaskAssignmentDto>>> GetMyTasks() =>
            Ok(await _onboarding.GetEmployeeTasksAsync(GetEmployeeId()));

        [HttpGet("tasks/{employeeId}")]
        [Authorize(Roles = "HrManager,Manager,Admin")]
        public async Task<ActionResult<List<TaskAssignmentDto>>> GetTasksForEmployee(Guid employeeId) =>
            Ok(await _onboarding.GetEmployeeTasksAsync(employeeId));

        [HttpPut("tasks/{assignmentId}/status")]
        public async Task<ActionResult<TaskAssignmentDto>> UpdateTaskStatus(
            Guid assignmentId, [FromBody] UpdateTaskStatusRequest request)
        {
            try { return Ok(await _onboarding.UpdateTaskStatusAsync(assignmentId, request)); }
            catch (KeyNotFoundException) { return NotFound(); }
        }

        [HttpGet("plans/{planId}")]
        public async Task<ActionResult<OnboardingPlanDto>> GetPlan(Guid planId)
        {
            var plan = await _onboarding.GetPlanAsync(planId);
            return plan == null ? NotFound() : Ok(plan);
        }

        [HttpPost("plans")]
        [Authorize(Roles = "HrManager,Admin")]
        public async Task<ActionResult<OnboardingPlanDto>> CreatePlan([FromBody] CreateOnboardingPlanRequest request) =>
            Ok(await _onboarding.CreatePlanAsync(request));

        [HttpPost("plans/{planId}/assign/{employeeId}")]
        [Authorize(Roles = "HrManager,Admin")]
        public async Task<IActionResult> AssignPlan(Guid planId, Guid employeeId)
        {
            try
            {
                await _onboarding.AssignPlanToEmployeeAsync(planId, employeeId);
                return NoContent();
            }
            catch (KeyNotFoundException ex) { return NotFound(ex.Message); }
        }

        [HttpGet("checkpoints")]
        public async Task<ActionResult<List<CheckpointDto>>> GetMyCheckpoints() =>
            Ok(await _onboarding.GetCheckpointsAsync(GetEmployeeId()));

        [HttpGet("checkpoints/{employeeId}")]
        [Authorize(Roles = "HrManager,Manager,Admin")]
        public async Task<ActionResult<List<CheckpointDto>>> GetCheckpoints(Guid employeeId) =>
            Ok(await _onboarding.GetCheckpointsAsync(employeeId));

        [HttpPut("checkpoints/{checkpointId}/complete")]
        [Authorize(Roles = "HrManager,Admin")]
        public async Task<ActionResult<CheckpointDto>> CompleteCheckpoint(
            Guid checkpointId, [FromBody] CompleteCheckpointRequest request)
        {
            try { return Ok(await _onboarding.CompleteCheckpointAsync(checkpointId, request)); }
            catch (KeyNotFoundException) { return NotFound(); }
        }

        private Guid GetEmployeeId() =>
            Guid.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
    }
}
