﻿using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace KMGOnboardingAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class NotificationsController : ControllerBase
    {
        private readonly INotificationService _notifications;

        public NotificationsController(INotificationService notifications) => _notifications = notifications;

        [HttpGet]
        public async Task<ActionResult<List<NotificationDto>>> GetAll([FromQuery] bool unreadOnly = false) =>
            Ok(await _notifications.GetForEmployeeAsync(GetEmployeeId(), unreadOnly));

        [HttpPut("{id}/read")]
        public async Task<IActionResult> MarkRead(Guid id)
        {
            await _notifications.MarkAsReadAsync(id);
            return NoContent();
        }

        [HttpPut("read-all")]
        public async Task<IActionResult> MarkAllRead()
        {
            await _notifications.MarkAllAsReadAsync(GetEmployeeId());
            return NoContent();
        }

        private Guid GetEmployeeId() =>
            Guid.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
    }
}
