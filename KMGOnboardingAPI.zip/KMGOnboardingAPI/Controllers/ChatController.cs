﻿using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.DTOs.ForService;
using KMGOnboardingAPI.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace KMGOnboardingAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ChatController : ControllerBase
    {
        private readonly IChatService _chat;

        public ChatController(IChatService chat) => _chat = chat;

        [HttpGet("rooms")]
        public async Task<ActionResult<List<ChatRoomDto>>> GetRooms() =>
            Ok(await _chat.GetRoomsForEmployeeAsync(GetEmployeeId()));

        [HttpPost("rooms")]
        public async Task<ActionResult<ChatRoomDto>> CreateRoom([FromBody] CreateRoomRequest request) =>
            Ok(await _chat.CreateRoomAsync(request, GetEmployeeId()));

        [HttpGet("rooms/{roomId}/messages")]
        public async Task<ActionResult<List<ChatMessageDto>>> GetMessages(
            Guid roomId, [FromQuery] int page = 0, [FromQuery] int pageSize = 50) =>
            Ok(await _chat.GetMessagesAsync(roomId, page, pageSize, GetEmployeeId()));

        [HttpPost("rooms/{roomId}/messages")]
        public async Task<ActionResult<ChatMessageDto>> SendMessage(
            Guid roomId, [FromBody] SendMessageRequest request) =>
            Ok(await _chat.SendMessageAsync(roomId, request, GetEmployeeId()));

        [HttpPost("messages/{messageId}/reactions")]
        public async Task<IActionResult> AddReaction(Guid messageId, [FromBody] string emoji)
        {
            await _chat.AddReactionAsync(messageId, emoji, GetEmployeeId());
            return NoContent();
        }

        private Guid GetEmployeeId() =>
            Guid.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
    }
}
