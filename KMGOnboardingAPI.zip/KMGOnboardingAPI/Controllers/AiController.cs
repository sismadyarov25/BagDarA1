﻿using KMGOnboardingAPI.DTOs.AI;
using KMGOnboardingAPI.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace KMGOnboardingAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class AiController : ControllerBase
    {
        private readonly IAiService _ai;
        private readonly IEmployeeService _employees;

        public AiController(IAiService ai, IEmployeeService employees)
        {
            _ai = ai;
            _employees = employees;
        }

        [HttpPost("chat")]
        public async Task<ActionResult<AiChatResponse>> Chat([FromBody] AiChatRequest request)
        {
            var employee = await _employees.GetByIdAsync(GetEmployeeId());
            var context = employee != null
                ? $"Name: {employee.FirstName} {employee.LastName}, Position: {employee.Position}, Department: {employee.Department}, Onboarding Progress: {employee.OnboardingProgress}%"
                : null;
            return Ok(await _ai.ChatAsync(request, context));
        }

        [HttpPost("insights/{employeeId}")]
        [Authorize(Roles = "HrManager,Admin")]
        public async Task<ActionResult<AiInsightDto>> GenerateInsight(Guid employeeId)
        {
            try { return Ok(await _ai.GenerateInsightAsync(employeeId)); }
            catch (KeyNotFoundException) { return NotFound(); }
        }

        [HttpGet("insights/me")]
        public async Task<ActionResult<AiInsightDto>> GetMyInsight()
        {
            try { return Ok(await _ai.GenerateInsightAsync(GetEmployeeId())); }
            catch { return NotFound(); }
        }

        [HttpPost("welcome/{employeeId}")]
        public async Task<ActionResult<string>> GenerateWelcome(Guid employeeId) =>
            Ok(await _ai.GeneratePersonalizedWelcomeAsync(employeeId));

        [HttpPost("suggest-tasks")]
        [Authorize(Roles = "HrManager,Admin")]
        public async Task<ActionResult<List<string>>> SuggestTasks(
            [FromQuery] string department, [FromQuery] string position) =>
            Ok(await _ai.SuggestTasksAsync(department, position));

        [HttpPost("translate")]
        public async Task<ActionResult<string>> Translate([FromBody] string text) =>
            Ok(await _ai.TranslateToKazakhAsync(text));

        private Guid GetEmployeeId() =>
            Guid.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
    }
}
