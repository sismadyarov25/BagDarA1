﻿using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.DTOs.ForService;
using KMGOnboardingAPI.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace KMGOnboardingAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class EmployeesController : ControllerBase
    {
        private readonly IEmployeeService _employees;

        public EmployeesController(IEmployeeService employees) => _employees = employees;

        [HttpGet]
        public async Task<ActionResult<List<EmployeeSummaryDto>>> GetAll(
            [FromQuery] string? department, [FromQuery] string? search) =>
            Ok(await _employees.GetAllAsync(department, search));

        [HttpGet("{id}")]
        public async Task<ActionResult<EmployeeDto>> GetById(Guid id)
        {
            var emp = await _employees.GetByIdAsync(id);
            return emp == null ? NotFound() : Ok(emp);
        }

        [HttpGet("me")]
        public async Task<ActionResult<EmployeeDto>> GetMe()
        {
            var emp = await _employees.GetByIdAsync(GetEmployeeId());
            return emp == null ? NotFound() : Ok(emp);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<EmployeeDto>> Update(Guid id, [FromBody] UpdateEmployeeRequest request)
        {
            if (GetEmployeeId() != id && !User.IsInRole("HrManager") && !User.IsInRole("Admin"))
                return Forbid();
            try { return Ok(await _employees.UpdateAsync(id, request)); }
            catch (KeyNotFoundException) { return NotFound(); }
        }

        [HttpGet("dashboard")]
        public async Task<ActionResult<DashboardDto>> GetDashboard() =>
            Ok(await _employees.GetDashboardAsync(GetEmployeeId()));

        [HttpGet("at-risk")]
        [Authorize(Roles = "HrManager,Admin")]
        public async Task<ActionResult<List<EmployeeSummaryDto>>> GetAtRisk() =>
            Ok(await _employees.GetAtRiskEmployeesAsync());

        private Guid GetEmployeeId() =>
            Guid.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
    }
}
