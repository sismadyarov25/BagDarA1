﻿using KMGOnboardingAPI.DTOs.Register;
using KMGOnboardingAPI.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace KMGOnboardingAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _auth;

        public AuthController(IAuthService auth) => _auth = auth;

        [HttpPost("login")]
        public async Task<ActionResult<AuthResponse>> Login([FromBody] LoginRequest request)
        {
            try { return Ok(await _auth.LoginAsync(request)); }
            catch (UnauthorizedAccessException) { return Unauthorized("Invalid credentials"); }
        }

        [HttpPost("register")]
        public async Task<ActionResult<AuthResponse>> Register([FromBody] RegisterRequest request)
        {
            try { return Ok(await _auth.RegisterAsync(request)); }
            catch (InvalidOperationException ex) { return Conflict(ex.Message); }
        }

        [HttpPost("refresh")]
        public async Task<ActionResult<AuthResponse>> Refresh([FromBody] string refreshToken)
        {
            try { return Ok(await _auth.RefreshTokenAsync(refreshToken)); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
        }

        [Authorize]
        [HttpPost("logout")]
        public async Task<IActionResult> Logout()
        {
            await _auth.RevokeTokenAsync(GetEmployeeId());
            return NoContent();
        }

        private Guid GetEmployeeId() =>
            Guid.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
    }
}
