﻿using KMGOnboardingAPI.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace KMGOnboardingAPI.Controllers.FeaturedControllers
{
    [ApiController]
    [Route("api/digest")]
    [Authorize(Roles = "HrManager,Admin")]
    public class DigestController : ControllerBase
    {
        private readonly IEmailDigestService _digest;

        public DigestController(IEmailDigestService digest)
        {
            _digest = digest;
        }

        [HttpPost("send-now")]
        public async Task<IActionResult> SendNow()
        {
            await _digest.SendWeeklyHrDigestAsync();
            return Ok(new { message = "Digest sent to all HR managers" });
        }

        [HttpPost("burnout-alert/{employeeId:guid}")]
        public async Task<IActionResult> SendBurnoutAlert(Guid employeeId, [FromBody] BurnoutAlertRequest request)
        {
            await _digest.SendBurnoutAlertEmailAsync(employeeId, request.BurnoutRisk, request.Signals);
            return Ok(new { message = "Alert email sent" });
        }
    }

    public record BurnoutAlertRequest(double BurnoutRisk, string Signals);
}
