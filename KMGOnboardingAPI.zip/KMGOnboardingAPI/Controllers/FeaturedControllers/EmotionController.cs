﻿using KMGOnboardingAPI.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace KMGOnboardingAPI.Controllers.FeaturedControllers
{
    [ApiController]
    [Route("api/emotion")]
    [Authorize]
    public class EmotionController : ControllerBase
    {
        private readonly IEmotionMonitorService _emotionService;

        public EmotionController(IEmotionMonitorService emotionService)
        {
            _emotionService = emotionService;
        }

        [HttpPost("analyze/me")]
        public async Task<IActionResult> AnalyzeMyself()
        {
            var employeeId = GetEmployeeId();
            var result = await _emotionService.AnalyzeEmployeeAsync(employeeId);
            return Ok(result);
        }

        [HttpPost("analyze/{employeeId:guid}")]
        [Authorize(Roles = "HrManager,Admin")]
        public async Task<IActionResult> AnalyzeEmployee(Guid employeeId)
        {
            var result = await _emotionService.AnalyzeEmployeeAsync(employeeId);
            return Ok(result);
        }

        [HttpGet("history/me")]
        public async Task<IActionResult> GetMyHistory([FromQuery] int days = 30)
        {
            var employeeId = GetEmployeeId();
            var history = await _emotionService.GetEmployeeHistoryAsync(employeeId, days);
            return Ok(history);
        }

        [HttpGet("history/{employeeId:guid}")]
        [Authorize(Roles = "HrManager,Admin,Manager")]
        public async Task<IActionResult> GetEmployeeHistory(Guid employeeId, [FromQuery] int days = 30)
        {
            var history = await _emotionService.GetEmployeeHistoryAsync(employeeId, days);
            return Ok(history);
        }

        [HttpGet("dashboard")]
        [Authorize(Roles = "HrManager,Admin")]
        public async Task<IActionResult> GetHrDashboard()
        {
            var dashboard = await _emotionService.GetHrDashboardAsync();
            return Ok(dashboard);
        }

        private Guid GetEmployeeId()
        {
            var claim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            return Guid.TryParse(claim, out var id) ? id : throw new UnauthorizedAccessException();
        }
    }
}
