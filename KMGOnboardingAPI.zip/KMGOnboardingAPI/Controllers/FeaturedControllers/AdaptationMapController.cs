﻿using KMGOnboardingAPI.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace KMGOnboardingAPI.Controllers.FeaturedControllers
{
    [ApiController]
    [Route("api/adaptation")]
    [Authorize]
    public class AdaptationMapController : ControllerBase
    {
        private readonly IAdaptationMapService _mapService;

        public AdaptationMapController(IAdaptationMapService mapService)
        {
            _mapService = mapService;
        }

        [HttpGet("map/me")]
        public async Task<IActionResult> GetMyMap()
        {
            var employeeId = GetEmployeeId();
            var map = await _mapService.GetMapAsync(employeeId);
            return Ok(map);
        }

        [HttpGet("map/{employeeId:guid}")]
        [Authorize(Roles = "HrManager,Admin,Manager")]
        public async Task<IActionResult> GetEmployeeMap(Guid employeeId)
        {
            var map = await _mapService.GetMapAsync(employeeId);
            return Ok(map);
        }

        [HttpPost("map/me/initialize")]
        public async Task<IActionResult> InitializeMyMap()
        {
            var employeeId = GetEmployeeId();
            var map = await _mapService.InitializeMapAsync(employeeId);
            return Ok(map);
        }

        [HttpPost("milestones/{milestoneId:guid}/complete")]
        public async Task<IActionResult> CompleteMilestone(Guid milestoneId)
        {
            var employeeId = GetEmployeeId();
            var milestone = await _mapService.CompleteMilestoneAsync(milestoneId, employeeId);
            return Ok(milestone);
        }

        [HttpGet("weekly-plan/me")]
        public async Task<IActionResult> GetMyWeeklyPlan([FromQuery] int? week = null)
        {
            var employeeId = GetEmployeeId();
            var plan = await _mapService.GetOrGenerateWeeklyPlanAsync(employeeId, week);
            return Ok(plan);
        }

        [HttpGet("weekly-plan/{employeeId:guid}")]
        [Authorize(Roles = "HrManager,Admin")]
        public async Task<IActionResult> GetEmployeeWeeklyPlan(Guid employeeId, [FromQuery] int? week = null)
        {
            var plan = await _mapService.GetOrGenerateWeeklyPlanAsync(employeeId, week);
            return Ok(plan);
        }

        [HttpPost("weekly-plan/{planId:guid}/acknowledge")]
        public async Task<IActionResult> AcknowledgePlan(Guid planId)
        {
            var employeeId = GetEmployeeId();
            var plan = await _mapService.AcknowledgeWeeklyPlanAsync(planId, employeeId);
            return Ok(plan);
        }

        private Guid GetEmployeeId()
        {
            var claim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            return Guid.TryParse(claim, out var id) ? id : throw new UnauthorizedAccessException();
        }
    }
}
