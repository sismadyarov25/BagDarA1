﻿using KMGOnboardingAPI.DTOs.Language;
using KMGOnboardingAPI.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace KMGOnboardingAPI.Controllers.FeaturedControllers
{
    [ApiController]
    [Route("api/translate")]
    [Authorize]
    public class TranslationController : ControllerBase
    {
        private readonly ITranslationService _translationService;

        public TranslationController(ITranslationService translationService)
        {
            _translationService = translationService;
        }

        [HttpPost("message")]
        public async Task<IActionResult> TranslateMessage([FromBody] TranslateMessageRequest request)
        {
            var employeeId = GetEmployeeId();
            var result = await _translationService.TranslateMessageAsync(
                request.MessageId, request.TargetLanguage, employeeId);
            return Ok(result);
        }

        [HttpPost("messages/bulk")]
        public async Task<IActionResult> BulkTranslate([FromBody] BulkTranslateRequest request)
        {
            var employeeId = GetEmployeeId();
            var results = await _translationService.BulkTranslateAsync(
                request.MessageIds, request.TargetLanguage, employeeId);
            return Ok(results);
        }

        [HttpPost("detect")]
        public async Task<IActionResult> DetectLanguage([FromBody] DetectLanguageRequest request)
        {
            var lang = await _translationService.DetectLanguageAsync(request.Text);
            return Ok(new { language = lang, languageName = GetLanguageName(lang) });
        }

        [HttpPost("preference")]
        public async Task<IActionResult> SetLanguagePreference([FromBody] LanguagePreferenceRequest request)
        {
            var employeeId = GetEmployeeId();
            await _translationService.SetEmployeeLanguagePreferenceAsync(employeeId, request.Language);
            return Ok(new { message = "Language preference saved", language = request.Language });
        }

        [HttpGet("preference")]
        public async Task<IActionResult> GetLanguagePreference()
        {
            var employeeId = GetEmployeeId();
            var lang = await _translationService.GetEmployeeLanguagePreferenceAsync(employeeId) ?? "en";
            return Ok(new { language = lang, languageName = GetLanguageName(lang) });
        }

        [HttpGet("supported")]
        [AllowAnonymous]
        public IActionResult GetSupportedLanguages()
        {
            return Ok(new[]
            {
            new { code = "en", name = "English", nativeName = "English", flag = "🇬🇧" },
            new { code = "ru", name = "Russian", nativeName = "Русский", flag = "🇷🇺" },
            new { code = "kk", name = "Kazakh", nativeName = "Қазақша", flag = "🇰🇿" }
        });
        }

        private Guid GetEmployeeId()
        {
            var claim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            return Guid.TryParse(claim, out var id) ? id : throw new UnauthorizedAccessException();
        }

        private static string GetLanguageName(string code) => code switch
        {
            "ru" => "Russian",
            "kk" => "Kazakh",
            _ => "English"
        };
    }

    public record DetectLanguageRequest(string Text);
}
