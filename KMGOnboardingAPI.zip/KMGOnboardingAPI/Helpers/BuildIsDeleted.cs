﻿using System.Linq.Expressions;

namespace KMGOnboardingAPI.Helpers
{
    public static class BuildIsDeleted
    {
        public static LambdaExpression BuildIsDeletedFilter(Type type)
        {
            var param = Expression.Parameter(type, "e");
            var prop = Expression.Property(param, "IsDeleted");
            var body = Expression.Equal(prop, Expression.Constant(false));

            return Expression.Lambda(body, param);
        }
    }
}
