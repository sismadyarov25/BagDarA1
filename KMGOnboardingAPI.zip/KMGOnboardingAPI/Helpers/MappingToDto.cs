﻿using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.Models.Entities;

namespace KMGOnboardingAPI.Helpers
{
    public static class MappingToDto
    {
        public static EmployeeDto MapToDto(Employee e) => new(
            e.Id, e.FirstName, e.LastName, e.Email, e.Position,
            e.Department, e.HireDate, e.AvatarUrl, e.Role,
            e.OnboardingStatus, e.OnboardingProgress, e.PhoneNumber
        );
    }
}
