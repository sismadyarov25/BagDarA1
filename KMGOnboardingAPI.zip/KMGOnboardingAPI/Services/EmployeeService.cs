﻿using KMGOnboardingAPI.Data;
using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.DTOs.ForService;
using KMGOnboardingAPI.Helpers;
using KMGOnboardingAPI.Interfaces;
using KMGOnboardingAPI.Models.Entities;
using KMGOnboardingAPI.Models.Enums;
using Microsoft.EntityFrameworkCore;

namespace KMGOnboardingAPI.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly AppDbContext _dbContext;
        private readonly ILogger<EmployeeService> _logger;

        public EmployeeService(AppDbContext dbContext, ILogger<EmployeeService> logger)
        {
            _dbContext = dbContext;
            _logger = logger;
        }

        public async Task<EmployeeDto?> GetByIdAsync(Guid id)
        {
            var employee = await _dbContext.Employees.FindAsync(id);

            return employee != null ? 
                MappingToDto.MapToDto(employee) : null;
        }

        public async Task<List<EmployeeSummaryDto>> GetAllAsync(string? department = null, string? search = null)
        {
            var employeesQuery = _dbContext.Employees.AsQueryable();

            if (!string.IsNullOrWhiteSpace(department))
                employeesQuery = employeesQuery.Where(x => x.Department == department);

            if (!string.IsNullOrWhiteSpace(search))
                employeesQuery = employeesQuery.Where(
                    x => x.FirstName.Contains(search) ||
                    x.LastName.Contains(search) ||
                    x.Email.Contains(search) || 
                    x.Position.Contains(search));

            return await employeesQuery.Select(e => new EmployeeSummaryDto
            (
                e.Id,
                e.FirstName + " " + e.LastName,
                e.Position,
                e.Department,
                e.AvatarUrl,
                e.OnboardingStatus,
                e.OnboardingProgress,
                (int)(DateTime.UtcNow - e.HireDate).TotalDays
            )).ToListAsync();
        }

        public async Task<EmployeeDto> UpdateAsync(Guid id, UpdateEmployeeRequest request)
        {
            var user = await _dbContext.Employees.FindAsync(id) 
                ?? throw new KeyNotFoundException($"Employee with id {id} not found.");

            if (request.FirstName != null) user.FirstName = request.FirstName;
            if (request.LastName != null) user.LastName = request.LastName;
            if (request.PhoneNumber != null) user.PhoneNumber = request.PhoneNumber;
            if (request.AvatarUrl != null) user.AvatarUrl = request.AvatarUrl;

            await _dbContext.SaveChangesAsync();
            return MappingToDto.MapToDto(user);
        }

        public async Task<DashboardDto> GetDashboardAsync(Guid requestingEmployeeId)
        {
            var employee = await _dbContext.Employees.FindAsync(requestingEmployeeId);

            var totalEmployees = await _dbContext.Employees.CountAsync();

            var activeOnboarding = await _dbContext.Employees
                .CountAsync(e => e.OnboardingStatus == OnboardingStatus.InProgress ||
                                 e.OnboardingStatus == OnboardingStatus.OnTrack);

            var thisMonthStart = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, 1);

            var completedThisMonth = await _dbContext.Employees
                .CountAsync(e => e.OnboardingStatus == OnboardingStatus.Completed &&
                                 e.UpdatedAt >= thisMonthStart);

            var atRiskCount = await _dbContext.Employees
                .CountAsync(e => e.OnboardingStatus == OnboardingStatus.AtRisk);

            var avgEngagement = await _dbContext.AiInsights.AnyAsync()
                ? await _dbContext.AiInsights.AverageAsync(a => a.EngagementScore)
                : 0.0;

            var recentHires = await _dbContext.Employees
                .OrderByDescending(e => e.HireDate)
                .Take(5)
                .Select(e => new EmployeeSummaryDto(
                    e.Id,
                    e.FirstName + " " + e.LastName,
                    e.Position,
                    e.Department,
                    e.AvatarUrl,
                    e.OnboardingStatus,
                    e.OnboardingProgress,
                    (int)(DateTime.UtcNow - e.HireDate).TotalDays
                )).ToListAsync();

            var overdueTasks = await _dbContext.TaskAssignments
                .Include(t => t.Task)
                .Include(t => t.Employee)
                .Where(t => t.Status == AssignmentStatus.Overdue)
                .Take(10)
                .Select(t => new TaskSummaryDto(
                    t.Id,
                    t.Task.Title,
                    t.Task.Category.ToString(),
                    t.Employee.FirstName + " " + t.Employee.LastName,
                    t.Employee.HireDate.AddDays(t.Task.DayNumber),
                    t.Status
                )).ToListAsync();

            var notifications = await _dbContext.Notifications
                .Where(n => n.EmployeeId == requestingEmployeeId && !n.IsRead)
                .OrderByDescending(n => n.CreatedAt)
                .Take(5)
                .Select(n => new NotificationDto(
                    n.Id, n.Title, n.Body, n.Type, n.IsRead, n.CreatedAt, n.ActionUrl
                )).ToListAsync();

            var avgDays = await _dbContext.Employees
                .Where(e => e.OnboardingStatus == OnboardingStatus.Completed && e.UpdatedAt.HasValue)
                .Select(e => (double)(e.UpdatedAt!.Value - e.HireDate).TotalDays)
                .DefaultIfEmpty(0)
                .AverageAsync();

            var completionByCategory = await _dbContext.TaskAssignments
                .Include(t => t.Task)
                .Where(t => t.Status == AssignmentStatus.Completed)
                .GroupBy(t => t.Task.Category)
                .Select(g => new { Category = g.Key.ToString(), Count = g.Count() })
                .ToDictionaryAsync(x => x.Category, x => x.Count);

            var metrics = new OnboardingMetricsDto(
                Math.Round(avgDays, 1),
                totalEmployees > 0 ? Math.Round((double)(totalEmployees - atRiskCount) / totalEmployees * 100, 1) : 100,
                await _dbContext.OnboardingCheckpoints.Where(c => c.SatisfactionScore.HasValue)
                    .Select(c => (double?)c.SatisfactionScore)
                    .DefaultIfEmpty(0)
                    .AverageAsync() ?? 0,
                completionByCategory
            );

            return new DashboardDto(
                totalEmployees,
                activeOnboarding,
                completedThisMonth,
                atRiskCount,
                Math.Round(avgEngagement, 1),
                recentHires,
                overdueTasks,
                notifications,
                metrics
            );
        }

        public async Task<List<EmployeeSummaryDto>> GetAtRiskEmployeesAsync()
        {
            return await _dbContext.Employees
            .Where(e => e.OnboardingStatus == OnboardingStatus.AtRisk)
            .Select(e => new EmployeeSummaryDto(
                e.Id,
                e.FirstName + " " + e.LastName,
                e.Position,
                e.Department,
                e.AvatarUrl,
                e.OnboardingStatus,
                e.OnboardingProgress,
                (int)(DateTime.UtcNow - e.HireDate).TotalDays
            )).ToListAsync();
        }
    }
}
