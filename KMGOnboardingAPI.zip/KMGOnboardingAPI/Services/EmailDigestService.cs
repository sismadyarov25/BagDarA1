﻿using KMGOnboardingAPI.Data;
using KMGOnboardingAPI.DTOs.AI;
using KMGOnboardingAPI.Interfaces;
using KMGOnboardingAPI.Models.Enums;
using Microsoft.EntityFrameworkCore;
using System.Drawing;
using System.Net;
using System.Net.Mail;
using System.Text;

namespace KMGOnboardingAPI.Services
{
    public class EmailDigestService : IEmailDigestService
    {
        private readonly AppDbContext _db;
        private readonly IAiService _ai;
        private readonly IConfiguration _config;
        private readonly ILogger<EmailDigestService> _logger;

        public EmailDigestService(
            AppDbContext db,
            IAiService ai,
            IConfiguration config,
            ILogger<EmailDigestService> logger)
        {
            _db = db;
            _ai = ai;
            _config = config;
            _logger = logger;
        }

        public async Task SendWeeklyHrDigestAsync()
        {
            var hrManagers = await _db.Employees
                .Where(e => e.Role == EmployeeRole.HrManager || e.Role == EmployeeRole.Admin)
                .ToListAsync();

            if (!hrManagers.Any())
            {
                _logger.LogInformation("No HR managers found — skipping weekly digest");
                return;
            }

            var weekStart = DateTime.UtcNow.AddDays(-7);

            var newHires = await _db.Employees
                .Where(e => e.HireDate >= weekStart)
                .ToListAsync();

            var completedThisWeek = await _db.TaskAssignments
                .Include(t => t.Employee)
                .Include(t => t.Task)
                .Where(t => t.Status == AssignmentStatus.Completed && t.CompletedAt >= weekStart)
                .ToListAsync();

            var atRiskEmployees = await _db.Employees
                .Where(e => e.OnboardingStatus == OnboardingStatus.AtRisk)
                .ToListAsync();

            var burnoutAlerts = await _db.EmotionSnapshots
                .Include(s => s.Employee)
                .Where(s => s.BurnoutRisk >= 0.65 && s.CreatedAt >= weekStart)
                .OrderByDescending(s => s.BurnoutRisk)
                .Take(10)
                .ToListAsync();

            var overdueTasks = await _db.TaskAssignments
                .Include(t => t.Employee)
                .Include(t => t.Task)
                .Where(t => t.Status == AssignmentStatus.Overdue)
                .ToListAsync();

            var aiSummaryContext = $"""
            Weekly HR digest data for KazMunaiGas onboarding platform:
            - New hires this week: {newHires.Count}
            - Tasks completed this week: {completedThisWeek.Count}
            - Employees at risk: {atRiskEmployees.Count}
            - Burnout alerts this week: {burnoutAlerts.Count}
            - Overdue tasks: {overdueTasks.Count}
            - At-risk employees: {string.Join(", ", atRiskEmployees.Select(e => $"{e.FirstName} {e.LastName} ({e.Department})"))}

            Write a professional 3-sentence executive summary for the HR team.
            Be direct and specific. Note the most urgent item if any.
            Language: English, professional tone.
            """;

            var summaryResponse = await _ai.ChatAsync(new AiChatRequest(aiSummaryContext));
            var aiSummary = summaryResponse.Reply;

            var html = BuildDigestHtml(
                newHires, completedThisWeek, atRiskEmployees,
                burnoutAlerts, overdueTasks, aiSummary);

            foreach (var hr in hrManagers)
            {
                await SendEmailAsync(
                    to: hr.Email,
                    toName: $"{hr.FirstName} {hr.LastName}",
                    subject: $"KMG Onboarding Weekly Digest — {DateTime.UtcNow:MMMM d, yyyy}",
                    htmlBody: html
                );
            }

            _logger.LogInformation(
                "Weekly HR digest sent to {Count} HR managers", hrManagers.Count);
        }

        public async Task SendBurnoutAlertEmailAsync(Guid employeeId, double burnoutRisk, string signals)
        {
            var employee = await _db.Employees.FindAsync(employeeId);
            if (employee == null) return;

            var hrManagers = await _db.Employees
                .Where(e => e.Role == EmployeeRole.HrManager || e.Role == EmployeeRole.Admin)
                .ToListAsync();

            var aiRecommendation = await _ai.ChatAsync(new AiChatRequest(
                $"""
            An employee at KMG shows high burnout risk ({burnoutRisk:P0}).
            Employee: {employee.FirstName} {employee.LastName}, {employee.Position}, {employee.Department}
            Signals: {signals}
            Days since hire: {(int)(DateTime.UtcNow - employee.HireDate).TotalDays}
            
            Write 2-3 specific, actionable recommendations for the HR manager.
            Be concrete — what to say in the check-in meeting, what to offer.
            """
            ));

            var html = BuildAlertHtml(employee, burnoutRisk, signals, aiRecommendation.Reply);

            foreach (var hr in hrManagers)
            {
                await SendEmailAsync(
                    to: hr.Email,
                    toName: $"{hr.FirstName} {hr.LastName}",
                    subject: $"Wellness alert — {employee.FirstName} {employee.LastName} needs attention",
                    htmlBody: html
                );
            }
        }

        private string BuildDigestHtml(
            List<Models.Entities.Employee> newHires,
            List<Models.Entities.TaskAssignment> completedTasks,
            List<Models.Entities.Employee> atRisk,
            List<Models.Entities.EmotionSnapshot> burnoutAlerts,
            List<Models.Entities.TaskAssignment> overdue,
            string aiSummary)
        {
            var sb = new StringBuilder();
            sb.AppendLine("""
            <!DOCTYPE html>
            <html lang="en">
            <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
              * { box-sizing: border-box; margin: 0; padding: 0; }
              body { font-family: -apple-system, 'Segoe UI', sans-serif; background: #F5F5F2; color: #1A1A1A; }
              .wrap { max-width: 600px; margin: 0 auto; padding: 32px 16px; }
              .header { background: #FFFFFF; border: 0.5px solid #D4D4CE; border-radius: 10px; padding: 28px 28px 20px; margin-bottom: 12px; }
              .logo { font-size: 11px; font-weight: 600; color: #00A650; letter-spacing: 1.5px; margin-bottom: 16px; }
              .h1 { font-size: 22px; font-weight: 500; color: #1A1A1A; line-height: 1.3; margin-bottom: 8px; }
              .meta { font-size: 13px; color: #8A8A80; }
              .ai-box { background: #E8F7EE; border: 0.5px solid #C8E6C9; border-radius: 8px; padding: 16px 18px; margin-bottom: 12px; }
              .ai-label { font-size: 11px; font-weight: 600; color: #27500A; letter-spacing: .8px; margin-bottom: 8px; }
              .ai-text { font-size: 14px; color: #1A3D12; line-height: 1.6; }
              .metrics { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-bottom: 12px; }
              .metric { background: #FFFFFF; border: 0.5px solid #D4D4CE; border-radius: 8px; padding: 14px 12px; text-align: center; }
              .metric-val { font-size: 26px; font-weight: 500; color: #1A1A1A; line-height: 1; }
              .metric-lbl { font-size: 11px; color: #8A8A80; margin-top: 4px; }
              .section { background: #FFFFFF; border: 0.5px solid #D4D4CE; border-radius: 10px; padding: 20px 24px; margin-bottom: 12px; }
              .section-title { font-size: 11px; font-weight: 600; color: #5A5A52; letter-spacing: .8px; margin-bottom: 14px; }
              .row { display: flex; align-items: center; justify-content: space-between; padding: 8px 0; border-bottom: 0.5px solid #F0F0EC; }
              .row:last-child { border-bottom: none; }
              .name { font-size: 13px; font-weight: 500; color: #1A1A1A; }
              .dept { font-size: 12px; color: #8A8A80; }
              .badge { display: inline-block; font-size: 11px; font-weight: 600; padding: 3px 10px; border-radius: 4px; }
              .badge-red { background: #FCEBEB; color: #791F1F; }
              .badge-green { background: #E8F7EE; color: #27500A; }
              .badge-amber { background: #FAEEDA; color: #633806; }
              .prog-wrap { background: #F0F0EC; border-radius: 3px; height: 4px; width: 100px; }
              .prog-fill { background: #00A650; border-radius: 3px; height: 4px; }
              .footer { text-align: center; padding: 24px 0 0; }
              .footer p { font-size: 12px; color: #8A8A80; line-height: 1.6; }
              .divider { height: 0.5px; background: #D4D4CE; margin: 4px 0 12px; }
              @media(max-width:480px){ .metrics { grid-template-columns: repeat(2,1fr); } }
            </style>
            </head>
            <body>
            <div class="wrap">
            """);

            sb.AppendLine($"""
            <div class="header">
              <div class="logo">KMG ONBOARD</div>
              <div class="h1">Weekly HR digest</div>
              <div class="meta">Week of {DateTime.UtcNow.AddDays(-7):MMMM d} — {DateTime.UtcNow:MMMM d, yyyy} &nbsp;·&nbsp; KazMunaiGas</div>
            </div>
            """);

            sb.AppendLine($"""
            <div class="ai-box">
              <div class="ai-label">AI SUMMARY</div>
              <div class="ai-text">{WebUtility.HtmlEncode(aiSummary)}</div>
            </div>
            """);

            sb.AppendLine($"""
            <div class="metrics">
              <div class="metric">
                <div class="metric-val">{newHires.Count}</div>
                <div class="metric-lbl">New hires</div>
              </div>
              <div class="metric">
                <div class="metric-val">{completedTasks.Count}</div>
                <div class="metric-lbl">Tasks done</div>
              </div>
              <div class="metric">
                <div class="metric-val" style="color:{(atRisk.Count > 0 ? "#A32D2D" : "#1A1A1A")}">{atRisk.Count}</div>
                <div class="metric-lbl">At risk</div>
              </div>
              <div class="metric">
                <div class="metric-val" style="color:{(overdue.Count > 0 ? "#BA7517" : "#1A1A1A")}">{overdue.Count}</div>
                <div class="metric-lbl">Overdue</div>
              </div>
            </div>
            """);

            if (burnoutAlerts.Any())
            {
                sb.AppendLine("""<div class="section">""");
                sb.AppendLine($"""<div class="section-title">BURNOUT ALERTS THIS WEEK ({burnoutAlerts.Count})</div>""");
                foreach (var alert in burnoutAlerts)
                {
                    sb.AppendLine($"""
                    <div class="row">
                      <div>
                        <div class="name">{WebUtility.HtmlEncode(alert.Employee.FirstName)} {WebUtility.HtmlEncode(alert.Employee.LastName)}</div>
                        <div class="dept">{WebUtility.HtmlEncode(alert.Employee.Department)} &nbsp;·&nbsp; Day {(int)(DateTime.UtcNow - alert.Employee.HireDate).TotalDays}</div>
                      </div>
                      <span class="badge badge-red">{alert.BurnoutRisk:P0} risk</span>
                    </div>
                    """);
                }
                sb.AppendLine("</div>");
            }

            if (atRisk.Any())
            {
                sb.AppendLine("""<div class="section">""");
                sb.AppendLine($"""<div class="section-title">EMPLOYEES AT RISK ({atRisk.Count})</div>""");
                foreach (var emp in atRisk)
                {
                    sb.AppendLine($"""
                    <div class="row">
                      <div>
                        <div class="name">{WebUtility.HtmlEncode(emp.FirstName)} {WebUtility.HtmlEncode(emp.LastName)}</div>
                        <div class="dept">{WebUtility.HtmlEncode(emp.Position)} &nbsp;·&nbsp; {WebUtility.HtmlEncode(emp.Department)}</div>
                      </div>
                      <div style="text-align:right">
                        <div class="prog-wrap"><div class="prog-fill" style="width:{emp.OnboardingProgress}px"></div></div>
                        <div style="font-size:11px;color:#8A8A80;margin-top:3px">{emp.OnboardingProgress}%</div>
                      </div>
                    </div>
                    """);
                }
                sb.AppendLine("</div>");
            }

            if (newHires.Any())
            {
                sb.AppendLine("""<div class="section">""");
                sb.AppendLine($"""<div class="section-title">NEW HIRES THIS WEEK ({newHires.Count})</div>""");
                foreach (var emp in newHires)
                {
                    sb.AppendLine($"""
                    <div class="row">
                      <div>
                        <div class="name">{WebUtility.HtmlEncode(emp.FirstName)} {WebUtility.HtmlEncode(emp.LastName)}</div>
                        <div class="dept">{WebUtility.HtmlEncode(emp.Position)} &nbsp;·&nbsp; {WebUtility.HtmlEncode(emp.Department)}</div>
                      </div>
                      <span class="badge badge-green">Joined {emp.HireDate:MMM d}</span>
                    </div>
                    """);
                }
                sb.AppendLine("</div>");
            }

            if (overdue.Any())
            {
                sb.AppendLine("""<div class="section">""");
                sb.AppendLine($"""<div class="section-title">OVERDUE TASKS ({overdue.Count})</div>""");
                foreach (var t in overdue.Take(8))
                {
                    sb.AppendLine($"""
                    <div class="row">
                      <div>
                        <div class="name">{WebUtility.HtmlEncode(t.Task.Title)}</div>
                        <div class="dept">{WebUtility.HtmlEncode(t.Employee.FirstName)} {WebUtility.HtmlEncode(t.Employee.LastName)}</div>
                      </div>
                      <span class="badge badge-amber">Overdue</span>
                    </div>
                    """);
                }
                sb.AppendLine("</div>");
            }

            sb.AppendLine($"""
            <div class="footer">
              <p>KazMunaiGas Onboarding Platform &nbsp;·&nbsp; Generated {DateTime.UtcNow:MMMM d, yyyy HH:mm} UTC<br>
              This digest is sent every Monday at 09:00 Almaty time.</p>
            </div>
            </div></body></html>
            """);

            return sb.ToString();
        }

        private string BuildAlertHtml(
            Models.Entities.Employee employee,
            double burnoutRisk,
            string signals,
            string aiRecommendation)
        {
            return $$"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <style>
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body { font-family: -apple-system, 'Segoe UI', sans-serif; background: #F5F5F2; color: #1A1A1A; }
            .wrap { max-width: 560px; margin: 0 auto; padding: 32px 16px; }
            .logo { font-size: 11px; font-weight: 600; color: #00A650; letter-spacing: 1.5px; margin-bottom: 16px; }
            .alert-card { background: #FCEBEB; border: 0.5px solid #F09595; border-radius: 10px; padding: 24px 28px; margin-bottom: 12px; }
            .alert-label { font-size: 11px; font-weight: 600; color: #791F1F; letter-spacing: .8px; margin-bottom: 12px; }
            .alert-name { font-size: 20px; font-weight: 500; color: #1A1A1A; margin-bottom: 4px; }
            .alert-meta { font-size: 13px; color: #5A5A52; margin-bottom: 16px; }
            .risk-val { font-size: 36px; font-weight: 500; color: #A32D2D; line-height: 1; }
            .ai-box { background: #FFFFFF; border: 0.5px solid #D4D4CE; border-radius: 10px; padding: 20px 24px; margin-bottom: 12px; }
            .ai-label { font-size: 11px; font-weight: 600; color: #5A5A52; letter-spacing: .8px; margin-bottom: 10px; }
            .ai-text { font-size: 14px; color: #1A1A1A; line-height: 1.6; white-space: pre-line; }
            .signals { background: #FAFAF8; border: 0.5px solid #D4D4CE; border-radius: 8px; padding: 14px 18px; }
            .sig-title { font-size: 11px; font-weight: 600; color: #8A8A80; letter-spacing: .8px; margin-bottom: 8px; }
            .sig-text { font-size: 13px; color: #5A5A52; line-height: 1.6; white-space: pre-line; }
            .footer { text-align: center; padding-top: 20px; font-size: 12px; color: #8A8A80; }
        </style>
    </head>
    <body>
    <div class="wrap">
        <div class="logo">KMG ONBOARD</div>
        <div class="alert-card">
            <div class="alert-label">WELLNESS ALERT</div>
            <div class="alert-name">{{WebUtility.HtmlEncode(employee.FirstName)}} {{WebUtility.HtmlEncode(employee.LastName)}}</div>
            <div class="alert-meta">{{WebUtility.HtmlEncode(employee.Position)}} &nbsp;·&nbsp; {{WebUtility.HtmlEncode(employee.Department)}} &nbsp;·&nbsp; Day -</div>
            <div class="risk-val">{{burnoutRisk:P0}}</div>
            <div style="font-size:12px; color:#8A8A80; margin-top:4px">burnout risk score</div>
        </div>
        <div class="ai-box">
            <div class="ai-label">RECOMMENDED ACTIONS</div>
            <div class="ai-text">{{WebUtility.HtmlEncode(aiRecommendation)}}</div>
        </div>
        <div class="signals">
            <div class="sig-title">DETECTED SIGNALS</div>
            <div class="sig-text">{{WebUtility.HtmlEncode(signals)}}</div>
        </div>
        <div class="footer">
            Sent automatically by KMG Wellness Monitor &nbsp;·&nbsp; {{DateTime.UtcNow:MMM d, yyyy HH:mm}} UTC
        </div>
    </div>
    </body>
    </html>
    """;
        }

        private async Task SendEmailAsync(string to, string toName, string subject, string htmlBody)
        {
            try
            {
                var host = _config["Email:SmtpHost"] ?? "smtp.gmail.com";
                var port = int.Parse(_config["Email:SmtpPort"] ?? "587");
                var useSsl = bool.Parse(_config["Email:UseSsl"] ?? "true");
                var senderAddress = _config["Email:SenderAddress"] ?? "noreply@kmg.kz";
                var senderName = _config["Email:SenderName"] ?? "KMG Onboarding";
                var username = _config["Email:Username"];
                var password = _config["Email:Password"];

                using var client = new SmtpClient(host, port)
                {
                    EnableSsl = useSsl,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    Credentials = (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password))
                        ? new NetworkCredential(username, password)
                        : null
                };

                var message = new MailMessage
                {
                    From = new MailAddress(senderAddress, senderName),
                    Subject = subject,
                    Body = htmlBody,
                    IsBodyHtml = true,
                    BodyEncoding = Encoding.UTF8,
                    SubjectEncoding = Encoding.UTF8
                };
                message.To.Add(new MailAddress(to, toName));

                await client.SendMailAsync(message);
                _logger.LogInformation("Email sent to {To}: {Subject}", to, subject);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to send email to {To}", to);
            }
        }
    }
}
