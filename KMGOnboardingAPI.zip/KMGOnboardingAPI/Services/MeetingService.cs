﻿using KMGOnboardingAPI.Data;
using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.Interfaces;
using KMGOnboardingAPI.Models.Entities;
using KMGOnboardingAPI.Models.Enums;
using Microsoft.EntityFrameworkCore;

namespace KMGOnboardingAPI.Services
{
    public class MeetingService : IMeetingService
    {
        private readonly AppDbContext _db;
        private readonly INotificationService _notifications;

        public MeetingService(AppDbContext db, INotificationService notifications)
        {
            _db = db;
            _notifications = notifications;
        }

        public async Task<List<MeetingDto>> GetForEmployeeAsync(Guid employeeId)
        {
            return await _db.MeetingParticipants
                .Include(p => p.Meeting).ThenInclude(m => m.Participants).ThenInclude(p => p.Employee)
                .Where(p => p.EmployeeId == employeeId)
                .OrderBy(p => p.Meeting.StartTime)
                .Select(p => MapToDto(p.Meeting, p.IsAccepted))
                .ToListAsync();
        }

        public async Task<MeetingDto> CreateAsync(CreateMeetingRequest request, Guid organizerId)
        {
            var meeting = new Meeting
            {
                Title = request.Title,
                Description = request.Description,
                StartTime = request.StartTime,
                EndTime = request.EndTime,
                MeetingUrl = request.MeetingUrl,
                Location = request.Location,
                MeetingType = (Models.Enums.MeetingType)request.MeetingType
            };

            var allParticipantIds = request.ParticipantIds
                .Append(organizerId)
                .Distinct()
                .ToList();

            meeting.Participants = allParticipantIds.Select(id => new MeetingParticipant
            {
                EmployeeId = id,
                IsAccepted = id == organizerId
            }).ToList();

            await _db.Meetings.AddAsync(meeting);
            await _db.SaveChangesAsync();

            var organizer = await _db.Employees.FindAsync(organizerId);
            foreach (var participantId in allParticipantIds.Where(id => id != organizerId))
            {
                await _notifications.SendAsync(
                    participantId,
                    $"Meeting scheduled: {meeting.Title}",
                    $"{organizer?.FirstName} {organizer?.LastName} scheduled a meeting on {meeting.StartTime:MMM d, HH:mm}",
                    Models.Enums.NotificationType.MeetingScheduled
                );
            }

            var full = await _db.Meetings
                .Include(m => m.Participants).ThenInclude(p => p.Employee)
                .FirstAsync(m => m.Id == meeting.Id);

            return MapToDto(full, true);
        }

        public async Task RespondAsync(Guid meetingId, Guid employeeId, bool accepted)
        {
            var participant = await _db.MeetingParticipants
                .FirstOrDefaultAsync(p => p.MeetingId == meetingId && p.EmployeeId == employeeId)
                ?? throw new KeyNotFoundException("Participant not found");

            participant.IsAccepted = accepted;
            await _db.SaveChangesAsync();
        }

        private static MeetingDto MapToDto(Meeting m, bool isAccepted) => new(
            m.Id,
            m.Title,
            m.Description,
            m.StartTime,
            m.EndTime,
            m.MeetingUrl,
            m.Location,
            (MeetingType)m.MeetingType,
            m.Participants.Select(p => new EmployeeDto(
                p.Employee.Id, p.Employee.FirstName, p.Employee.LastName,
                p.Employee.Email, p.Employee.Position, p.Employee.Department,
                p.Employee.HireDate, p.Employee.AvatarUrl, p.Employee.Role,
                p.Employee.OnboardingStatus, p.Employee.OnboardingProgress, p.Employee.PhoneNumber
            )).ToList(),
            isAccepted
        );
    }
}
