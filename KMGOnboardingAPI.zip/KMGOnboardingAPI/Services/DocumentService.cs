﻿using KMGOnboardingAPI.Data;
using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.DTOs.AI;
using KMGOnboardingAPI.DTOs.ForService;
using KMGOnboardingAPI.Interfaces;
using KMGOnboardingAPI.Models.Entities;
using KMGOnboardingAPI.Models.Enums;
using Microsoft.EntityFrameworkCore;

namespace KMGOnboardingAPI.Services
{
    public class DocumentService : IDocumentService
    {
        private readonly AppDbContext _db;
        private readonly IAiService _ai;

        public DocumentService(AppDbContext db, IAiService ai)
        {
            _db = db;
            _ai = ai;
        }

        public async Task<List<DocumentDto>> GetDocumentsAsync(
            string? category = null,
            string? department = null,
            bool publicOnly = false)
        {
            var query = _db.Documents.AsQueryable();

            if (!string.IsNullOrEmpty(category) &&
                Enum.TryParse<Models.Enums.DocumentCategory>(category, out var cat))
                query = query.Where(d => d.Category == cat);

            if (!string.IsNullOrEmpty(department))
                query = query.Where(d => d.Department == null || d.Department == department);

            if (publicOnly)
                query = query.Where(d => d.IsPublic);

            return await query
                .OrderByDescending(d => d.CreatedAt)
                .Select(d => MapToDto(d))
                .ToListAsync();
        }

        public async Task<DocumentDto?> GetByIdAsync(Guid id)
        {
            var doc = await _db.Documents.FindAsync(id);
            if (doc == null) return null;

            doc.DownloadCount++;
            await _db.SaveChangesAsync();

            return MapToDto(doc);
        }

        public async Task<DocumentDto> UploadAsync(UploadDocumentRequest request, Guid uploadedById)
        {
            var document = new Document
            {
                Title = request.Title,
                FileName = request.FileName,
                FileUrl = request.FileUrl,
                FileSizeBytes = request.FileSizeBytes,
                ContentType = request.ContentType,
                Category = (Models.Enums.DocumentCategory)request.Category,
                Department = request.Department,
                IsPublic = request.IsPublic,
                UploadedById = uploadedById
            };

            await _db.Documents.AddAsync(document);
            await _db.SaveChangesAsync();

            return MapToDto(document);
        }

        public async Task<string> GenerateAiSummaryAsync(Guid documentId)
        {
            var document = await _db.Documents.FindAsync(documentId)
                ?? throw new KeyNotFoundException("Document not found");

            var prompt = $"""
            Summarize this KMG corporate document for a new employee.
            Document title: {document.Title}
            Category: {document.Category}
            
            Provide 4-5 concise bullet points covering:
            - What this document is about
            - Key rules or requirements the employee must know
            - Any deadlines or mandatory actions
            - Who it applies to
            
            Write in plain, direct language. No corporate jargon.
            """;

            var response = await _ai.ChatAsync(new AiChatRequest(prompt));

            document.AiSummary = response.Reply;
            await _db.SaveChangesAsync();

            return response.Reply;
        }

        private static DocumentDto MapToDto(Document d) => new(
            d.Id, d.Title, d.FileName, d.FileUrl, d.FileSizeBytes,
            (DocumentCategory)d.Category, d.Department, d.IsPublic,
            d.AiSummary, d.DownloadCount, d.CreatedAt
        );
    }
}
