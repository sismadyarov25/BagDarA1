﻿using KMGOnboardingAPI.Data;
using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.DTOs.ForService;
using KMGOnboardingAPI.Interfaces;
using KMGOnboardingAPI.Models.Entities;
using KMGOnboardingAPI.Models.Enums;
using Microsoft.EntityFrameworkCore;

namespace KMGOnboardingAPI.Services
{
    public class ChatService : IChatService
    {
        private readonly AppDbContext _db;

        public ChatService(AppDbContext db)
        {
            _db = db;
        }

        public async Task<List<ChatRoomDto>> GetRoomsForEmployeeAsync(Guid employeeId)
        {
            var rooms = await _db.ChatRooms
                .AsNoTracking()
                .Include(r => r.Members)
                .Include(r => r.Messages.OrderByDescending(m => m.CreatedAt).Take(1))
                    .ThenInclude(m => m.Sender)
                .Where(r => r.Members.Any(m => m.EmployeeId == employeeId))
                .ToListAsync();

            var result = new List<ChatRoomDto>();
            foreach (var room in rooms)
            {
                var lastMsg = room.Messages.FirstOrDefault();
                var unread = await _db.ChatMessages
                    .CountAsync(m => m.RoomId == room.Id && m.CreatedAt > DateTime.UtcNow.AddDays(-7));

                ChatMessageDto? lastMsgDto = null;
                if (lastMsg != null)
                {
                    lastMsgDto = new ChatMessageDto(
                        lastMsg.Id, lastMsg.RoomId,
                        new SenderDto(lastMsg.Sender.Id, $"{lastMsg.Sender.FirstName} {lastMsg.Sender.LastName}", lastMsg.Sender.AvatarUrl),
                        lastMsg.Content, lastMsg.MessageType, lastMsg.CreatedAt,
                        lastMsg.IsEdited, lastMsg.ReplyToId, null, new List<ReactionDto>()
                    );
                }

                result.Add(new ChatRoomDto(
                    room.Id, room.Name, room.Description,
                    room.RoomType, room.Members.Count, lastMsgDto, unread
                ));
            }

            return result.OrderByDescending(r => r.LastMessage?.CreatedAt ?? DateTime.MinValue).ToList();
        }

        public async Task<List<ChatMessageDto>> GetMessagesAsync(Guid roomId, int page, int pageSize, Guid requestingEmployeeId)
        {
            var messages = await _db.ChatMessages
                .AsNoTracking()
                .Include(m => m.Sender)
                .Include(m => m.Reactions)
                .Include(m => m.ReplyTo)
                .Where(m => m.RoomId == roomId)
                .OrderByDescending(m => m.CreatedAt)
                .Skip(page * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return messages.Select(m => MapMessage(m, requestingEmployeeId)).OrderBy(m => m.CreatedAt).ToList();
        }

        public async Task<ChatMessageDto> SendMessageAsync(Guid roomId, SendMessageRequest request, Guid senderId)
        {
            var message = new ChatMessage
            {
                RoomId = roomId,
                SenderId = senderId,
                Content = request.Content,
                MessageType = (MessageType)request.MessageType,
                ReplyToId = request.ReplyToId
            };

            await _db.ChatMessages.AddAsync(message);
            await _db.SaveChangesAsync();

            await _db.Entry(message).Reference(m => m.Sender).LoadAsync();
            if (message.ReplyToId.HasValue)
                await _db.Entry(message).Reference(m => m.ReplyTo).LoadAsync();

            return MapMessage(message, senderId);
        }

        public async Task<ChatMessageDto?> EditMessageAsync(Guid messageId, string content, Guid requestingEmployeeId)
        {
            var message = await _db.ChatMessages
                .Include(m => m.Sender)
                .Include(m => m.Reactions)
                .FirstOrDefaultAsync(m => m.Id == messageId && m.SenderId == requestingEmployeeId);

            if (message == null) return null;

            message.Content = content;
            message.IsEdited = true;
            await _db.SaveChangesAsync();

            return MapMessage(message, requestingEmployeeId);
        }

        public async Task DeleteMessageAsync(Guid messageId, Guid requestingEmployeeId)
        {
            var message = await _db.ChatMessages.FirstOrDefaultAsync(m =>
                m.Id == messageId && m.SenderId == requestingEmployeeId);

            if (message != null)
            {
                message.IsDeleted = true;
                await _db.SaveChangesAsync();
            }
        }

        public async Task<ChatRoomDto> CreateRoomAsync(CreateRoomRequest request, Guid creatorId)
        {
            var room = new ChatRoom
            {
                Name = request.Name,
                Description = request.Description,
                RoomType = (RoomType)request.RoomType
            };

            var memberIds = request.MemberIds.Contains(creatorId)
                ? request.MemberIds
                : request.MemberIds.Append(creatorId).ToList();

            room.Members = memberIds.Select(id => new ChatRoomMember
            {
                EmployeeId = id,
                Room = room
            }).ToList();

            await _db.ChatRooms.AddAsync(room);
            await _db.SaveChangesAsync();

            return new ChatRoomDto(room.Id, room.Name, room.Description, room.RoomType, room.Members.Count, null, 0);
        }

        public async Task AddReactionAsync(Guid messageId, string emoji, Guid employeeId)
        {
            var existing = await _db.MessageReactions.FirstOrDefaultAsync(r =>
                r.MessageId == messageId && r.EmployeeId == employeeId && r.Emoji == emoji);

            if (existing != null)
                _db.MessageReactions.Remove(existing);
            else
                await _db.MessageReactions.AddAsync(new MessageReaction
                {
                    MessageId = messageId,
                    EmployeeId = employeeId,
                    Emoji = emoji
                });

            await _db.SaveChangesAsync();
        }

        private static ChatMessageDto MapMessage(ChatMessage m, Guid viewerId)
        {
            var reactionGroups = m.Reactions
                .GroupBy(r => r.Emoji)
                .Select(g => new ReactionDto(g.Key, g.Count(), g.Any(r => r.EmployeeId == viewerId)))
                .ToList();

            return new ChatMessageDto(
                m.Id, m.RoomId,
                new SenderDto(m.Sender.Id, $"{m.Sender.FirstName} {m.Sender.LastName}", m.Sender.AvatarUrl),
                m.Content, m.MessageType, m.CreatedAt, m.IsEdited,
                m.ReplyToId, m.ReplyTo?.Content, reactionGroups
            );
        }
    }
}
