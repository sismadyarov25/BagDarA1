﻿using KMGOnboardingAPI.Data;
using KMGOnboardingAPI.DTOs.AI;
using KMGOnboardingAPI.DTOs.Language;
using KMGOnboardingAPI.Interfaces;
using KMGOnboardingAPI.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using System.Text.Json;

namespace KMGOnboardingAPI.Services
{
    public class TranslationService : ITranslationService
    {
        private readonly AppDbContext _db;
        private readonly IAiService _ai;
        private readonly IDistributedCache _cache;
        private readonly ILogger<TranslationService> _logger;

        private static readonly HashSet<string> SUPPORTED_LANGUAGES = new(StringComparer.OrdinalIgnoreCase)
    {
        "en", "ru", "kk"
    };

        private static readonly Dictionary<string, string> LANGUAGE_NAMES = new(StringComparer.OrdinalIgnoreCase)
    {
        { "en", "English" },
        { "ru", "Russian (Русский)" },
        { "kk", "Kazakh (Қазақша)" }
    };

        public TranslationService(
            AppDbContext db,
            IAiService ai,
            IDistributedCache cache,
            ILogger<TranslationService> logger)
        {
            _db = db;
            _ai = ai;
            _cache = cache;
            _logger = logger;
        }

        public async Task<TranslatedMessageDto> TranslateMessageAsync(
            Guid messageId,
            string targetLanguage,
            Guid requestingEmployeeId)
        {
            targetLanguage = targetLanguage.ToLower();

            if (!SUPPORTED_LANGUAGES.Contains(targetLanguage))
                throw new ArgumentException($"Language '{targetLanguage}' not supported. Use: en, ru, kk");

            var message = await _db.ChatMessages
                .Include(m => m.Sender)
                .FirstOrDefaultAsync(m => m.Id == messageId)
                ?? throw new KeyNotFoundException("Message not found");

            var cacheKey = $"translation:{messageId}:{targetLanguage}";
            var cached = await TryGetFromCacheAsync<TranslatedMessageDto>(cacheKey);
            if (cached != null)
                return cached with { WasCached = true };

            var dbTranslation = await _db.MessageTranslations
                .FirstOrDefaultAsync(t => t.MessageId == messageId && t.TargetLanguage == targetLanguage);

            if (dbTranslation != null)
            {
                var cachedResult = new TranslatedMessageDto(
                    messageId, message.Content, dbTranslation.TranslatedContent, targetLanguage, true);
                await SetCacheAsync(cacheKey, cachedResult, TimeSpan.FromHours(24));
                return cachedResult;
            }

            var detectedLang = await DetectLanguageAsync(message.Content);
            if (string.Equals(detectedLang, targetLanguage, StringComparison.OrdinalIgnoreCase))
            {
                return new TranslatedMessageDto(messageId, message.Content, message.Content, targetLanguage, false);
            }

            var translatedText = await TranslateWithGeminiAsync(message.Content, targetLanguage);

            var translation = new MessageTranslation
            {
                MessageId = messageId,
                TargetLanguage = targetLanguage,
                TranslatedContent = translatedText,
                IsAutoTranslated = true
            };

            await _db.MessageTranslations.AddAsync(translation);
            await _db.SaveChangesAsync();

            var result = new TranslatedMessageDto(messageId, message.Content, translatedText, targetLanguage, false);
            await SetCacheAsync(cacheKey, result, TimeSpan.FromHours(24));

            _logger.LogDebug("Translated message {Id} to {Lang}", messageId, targetLanguage);
            return result;
        }

        public async Task<List<TranslatedMessageDto>> BulkTranslateAsync(
            List<Guid> messageIds,
            string targetLanguage,
            Guid requestingEmployeeId)
        {
            targetLanguage = targetLanguage.ToLower();
            if (!SUPPORTED_LANGUAGES.Contains(targetLanguage))
                throw new ArgumentException($"Language '{targetLanguage}' not supported.");

            var messages = await _db.ChatMessages
                .Where(m => messageIds.Contains(m.Id))
                .ToDictionaryAsync(x => x.Id);

            var existingTranslations = await _db.MessageTranslations
                .Where(t => messageIds.Contains(t.MessageId) && t.TargetLanguage == targetLanguage)
                .ToDictionaryAsync(t => t.MessageId);

            var results = new List<TranslatedMessageDto>();
            var toTranslate = new List<(Guid Id, string Content)>();

            foreach (var messageId in messageIds)
            {
                if (!messages.TryGetValue(messageId, out var msg)) continue;

                if (existingTranslations.TryGetValue(messageId, out var cached))
                {
                    results.Add(new TranslatedMessageDto(messageId, msg.Content, cached.TranslatedContent, targetLanguage, true));
                    continue;
                }

                toTranslate.Add((messageId, msg.Content));
            }

            if (toTranslate.Any())
            {
                var batchText = string.Join("\n---MSG---\n", toTranslate.Select(t => t.Content));
                var langName = LANGUAGE_NAMES.GetValueOrDefault(targetLanguage, targetLanguage);

                var prompt = $"""
                Translate each message below to {langName}.
                Messages are separated by ---MSG---.
                Return ONLY the translated messages separated by ---MSG---, in the same order.
                Preserve formatting, punctuation, and tone. Do not add explanations.

                {batchText}
                """;

                var response = await _ai.ChatAsync(new AiChatRequest(prompt));
                var translatedParts = response.Reply.Split("---MSG---");

                var newTranslations = new List<MessageTranslation>();
                for (int i = 0; i < toTranslate.Count && i < translatedParts.Length; i++)
                {
                    var translatedText = translatedParts[i].Trim();
                    var (msgId, originalContent) = toTranslate[i];

                    results.Add(new TranslatedMessageDto(msgId, originalContent, translatedText, targetLanguage, false));
                    newTranslations.Add(new MessageTranslation
                    {
                        MessageId = msgId,
                        TargetLanguage = targetLanguage,
                        TranslatedContent = translatedText,
                        IsAutoTranslated = true
                    });
                }

                if (newTranslations.Any())
                {
                    await _db.MessageTranslations.AddRangeAsync(newTranslations);
                    await _db.SaveChangesAsync();
                }
            }

            return results.OrderBy(r => messageIds.IndexOf(r.MessageId)).ToList();
        }

        public async Task SetEmployeeLanguagePreferenceAsync(Guid employeeId, string language)
        {
            language = language.ToLower();
            if (!SUPPORTED_LANGUAGES.Contains(language))
                throw new ArgumentException($"Unsupported language: {language}");

            await _cache.SetStringAsync(
                $"lang_pref:{employeeId}",
                language,
                new DistributedCacheEntryOptions { AbsoluteExpirationRelativeToNow = TimeSpan.FromDays(365) }
            );
        }

        public async Task<string?> GetEmployeeLanguagePreferenceAsync(Guid employeeId)
        {
            return await _cache.GetStringAsync($"lang_pref:{employeeId}");
        }

        public async Task<string> DetectLanguageAsync(string text)
        {
            if (string.IsNullOrWhiteSpace(text) || text.Length < 3) return "en";

            var cacheKey = $"langdetect:{text.GetHashCode()}";
            var cached = await _cache.GetStringAsync(cacheKey);
            if (cached != null) return cached;

            var hasKazakh = text.Any(c => "ӘәҒғҚқҢңӨөҰұҮүІі".Contains(c));
            if (hasKazakh)
            {
                await _cache.SetStringAsync(cacheKey, "kk",
                    new DistributedCacheEntryOptions { AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(1) });
                return "kk";
            }

            var hasCyrillic = text.Any(c => c >= '\u0400' && c <= '\u04FF');
            if (hasCyrillic)
            {
                await _cache.SetStringAsync(cacheKey, "ru",
                    new DistributedCacheEntryOptions { AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(1) });
                return "ru";
            }

            return "en";
        }

        private async Task<string> TranslateWithGeminiAsync(string text, string targetLanguage)
        {
            var langName = LANGUAGE_NAMES.GetValueOrDefault(targetLanguage, targetLanguage);

            var prompt = $"""
            Translate the following text to {langName}.
            Return ONLY the translation. No explanations, no notes.
            Preserve the tone, punctuation, and formatting exactly.

            Text to translate:
            {text}
            """;

            var response = await _ai.ChatAsync(new AiChatRequest(prompt));
            return response.Reply.Trim();
        }

        private async Task<T?> TryGetFromCacheAsync<T>(string key) where T : class
        {
            try
            {
                var value = await _cache.GetStringAsync(key);
                return value != null ? JsonSerializer.Deserialize<T>(value) : null;
            }
            catch { return null; }
        }

        private async Task SetCacheAsync<T>(string key, T value, TimeSpan expiry)
        {
            try
            {
                await _cache.SetStringAsync(key, JsonSerializer.Serialize(value),
                    new DistributedCacheEntryOptions { AbsoluteExpirationRelativeToNow = expiry });
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Cache set failed for key {Key}", key);
            }
        }
    }
}
