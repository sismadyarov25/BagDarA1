﻿using KMGOnboardingAPI.Data;
using KMGOnboardingAPI.DTOs.Register;
using KMGOnboardingAPI.Helpers;
using KMGOnboardingAPI.Interfaces;
using KMGOnboardingAPI.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace KMGOnboardingAPI.Services
{
    public class AuthService : IAuthService
    {
        private readonly AppDbContext _dbContext;
        private readonly ILogger<AuthService> _logger;
        private readonly IConfiguration _config;

        private readonly string _jwtSecret;
        private readonly string _jwtIssuer;
        private readonly string _jwtAudience;

        private readonly int _jwtExpirationMinutes;
        private readonly int _jwtRefreshTokenExpirationDays;

        public AuthService(AppDbContext db, ILogger<AuthService> logger, IConfiguration config)
        {
            _dbContext = db;
            _logger = logger;
            _config = config;

            _jwtSecret = _config["Jwt:Key"] ?? throw new ArgumentNullException("Jwt:Key");
            _jwtIssuer = _config["Jwt:Issuer"] ?? throw new ArgumentNullException("Jwt:Issuer");
            _jwtAudience = _config["Jwt:Audience"] ?? throw new ArgumentNullException("Jwt:Audience");
            _jwtExpirationMinutes = int.Parse(_config["Jwt:AccessTokenExpirationMinutes"] ?? throw new ArgumentNullException("Jwt:AccessTokenExpirationMinutes"));
            _jwtRefreshTokenExpirationDays = int.Parse(_config["Jwt:RefreshTokenExpirationDays"] ?? throw new ArgumentNullException("Jwt:RefreshTokenExpirationDays"));
        }

        private async Task<AuthResponse> GenerateTokensAsync(Employee emp)
        {
            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, emp.Id.ToString()), // soon must be changed
                new Claim(JwtRegisteredClaimNames.Email, emp.Email),
                new Claim(ClaimTypes.Role, emp.Role.ToString()),
                new Claim(ClaimTypes.Name, $"{emp.FirstName} {emp.LastName}"),
                new Claim("department", emp.Department),
                new Claim("position", emp.Position)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSecret));
            var alg = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _jwtIssuer,
                audience: _jwtAudience,
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(_jwtExpirationMinutes),
                signingCredentials: alg,
                notBefore: DateTime.UtcNow
            );

            var refreshToken = GenerateRefreshToken();
            emp.RefreshToken = refreshToken;
            emp.RefreshTokenExpiry = DateTime.UtcNow.AddDays(_jwtRefreshTokenExpirationDays);
            await _dbContext.SaveChangesAsync();

            return new AuthResponse(
                new JwtSecurityTokenHandler().WriteToken(token),
                refreshToken, 
                token.ValidTo,
                MappingToDto.MapToDto(emp)
            );

        }

        private static string GenerateRefreshToken()
        {
            using var numberConverter = RandomNumberGenerator.Create();

            var bytes = new byte[64];
            numberConverter.GetBytes(bytes);

            return Convert.ToBase64String(bytes);
        }

        public async Task<AuthResponse> LoginAsync(LoginRequest request)
        {
            var user = await _dbContext.Employees.FirstOrDefaultAsync(x => x.Email == request.Email.ToLowerInvariant()) 
                ?? throw new InvalidOperationException("User not found");
            if (user == null || !BCrypt.Net.BCrypt.Verify(request.Password, user.PasswordHash))
                throw new UnauthorizedAccessException("Invalid email or password");

            _logger.LogInformation("User logged in: {Email}", user.Email);
            return await GenerateTokensAsync(user);
        }

        public async Task<AuthResponse> RegisterAsync(RegisterRequest request)
        {
            if(await _dbContext.Employees.AnyAsync(x => x.Email == request.Email.ToLowerInvariant()))
                throw new InvalidOperationException("User already exists");

            var employee = new Employee
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email.ToLowerInvariant(),
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.Password),
                Position = request.Position,
                Department = request.Department,
                HireDate = request.HireDate,
                PhoneNumber = request.PhoneNumber,
                ManagerId = request.ManagerId
            };

            await _dbContext.Employees.AddAsync(employee);
            await _dbContext.SaveChangesAsync();

            _logger.LogInformation("New user registered: {Email}", employee.Email);
            return await GenerateTokensAsync(employee);
        }

        public async Task<AuthResponse> RefreshTokenAsync(string refreshToken)
        {
            var emp = await _dbContext.Employees.FirstOrDefaultAsync(
                x => x.RefreshToken == refreshToken 
                && x.RefreshTokenExpiry > DateTime.UtcNow);

            if(emp == null)
                throw new UnauthorizedAccessException("Invalid or expired refresh token");

            return await GenerateTokensAsync(emp);
        }

        public async Task RevokeTokenAsync(Guid employeeId)
        {
            var emp = await _dbContext.Employees.FindAsync(employeeId)
                ?? throw new UnauthorizedAccessException("User was not found");

            emp.RefreshToken = null;
            emp.RefreshTokenExpiry = null;
            await _dbContext.SaveChangesAsync();
        }
    }
}
