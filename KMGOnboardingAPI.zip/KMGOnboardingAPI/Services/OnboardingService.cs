﻿using KMGOnboardingAPI.Data;
using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.DTOs.ForService;
using KMGOnboardingAPI.Interfaces;
using KMGOnboardingAPI.Models.Entities;
using KMGOnboardingAPI.Models.Enums;
using Microsoft.EntityFrameworkCore;

namespace KMGOnboardingAPI.Services
{
    public class OnboardingService : IOnboardingService
    {
        private readonly AppDbContext _db;
        private readonly INotificationService _notifications;
        private readonly ILogger<OnboardingService> _logger;

        public OnboardingService(AppDbContext db, INotificationService notifications, ILogger<OnboardingService> logger)
        {
            _db = db;
            _notifications = notifications;
            _logger = logger;
        }

        public async Task<List<TaskAssignmentDto>> GetEmployeeTasksAsync(Guid employeeId)
        {
            var assignments = await _db.TaskAssignments
                .AsNoTracking()
                .Include(a => a.Task)
                .Where(a => a.EmployeeId == employeeId)
                .OrderBy(a => a.Task.DayNumber)
                .ThenBy(a => a.Task.Priority)
                .ToListAsync();

            return assignments.Select(MapAssignment).ToList();
        }

        public async Task<TaskAssignmentDto> UpdateTaskStatusAsync(Guid assignmentId, UpdateTaskStatusRequest request)
        {
            var assignment = await _db.TaskAssignments
                .Include(a => a.Task)
                .FirstOrDefaultAsync(a => a.Id == assignmentId)
                ?? throw new KeyNotFoundException("Task assignment not found");

            assignment.Status = request.Status;
            assignment.Notes = request.Notes ?? assignment.Notes;
            assignment.Score = request.Score ?? assignment.Score;

            if (request.Status == AssignmentStatus.Completed)
                assignment.CompletedAt = DateTime.UtcNow;

            await _db.SaveChangesAsync();

            var progress = await CalculateProgressAsync(assignment.EmployeeId);
            var employee = await _db.Employees.FindAsync(assignment.EmployeeId);
            if (employee != null)
            {
                employee.OnboardingProgress = progress;
                employee.OnboardingStatus = DetermineStatus(progress, employee.HireDate);
                await _db.SaveChangesAsync();
            }

            if (request.Status == AssignmentStatus.Completed)
            {
                await _notifications.SendAsync(
                    assignment.EmployeeId,
                    "Task Completed",
                    $"You've completed: {assignment.Task.Title}",
                    NotificationType.TaskAssigned
                );
            }

            return MapAssignment(assignment);
        }

        public async Task<OnboardingPlanDto?> GetPlanAsync(Guid planId)
        {
            var plan = await _db.OnboardingPlans
                .AsNoTracking()
                .Include(p => p.Tasks)
                .FirstOrDefaultAsync(p => p.Id == planId);

            return plan == null ? null : MapPlan(plan);
        }

        public async Task<OnboardingPlanDto> CreatePlanAsync(CreateOnboardingPlanRequest request)
        {
            var plan = new OnboardingPlan
            {
                Title = request.Title,
                Description = request.Description,
                Department = request.Department,
                Position = request.Position,
                DurationDays = request.DurationDays,
                IsTemplate = request.IsTemplate,
                Tasks = request.Tasks.Select(t => new OnboardingTask
                {
                    Title = t.Title,
                    Description = t.Description,
                    Category = (TaskCategory)(t.Category ?? TaskCategory.Training),
                    DayNumber = t.DayNumber,
                    EstimatedMinutes = t.EstimatedMinutes,
                    Priority = t.Priority,
                    IsRequired = t.IsRequired,
                    ResourceUrl = t.ResourceUrl
                }).ToList()
            };

            await _db.OnboardingPlans.AddAsync(plan);
            await _db.SaveChangesAsync();
            return MapPlan(plan);
        }

        public async Task AssignPlanToEmployeeAsync(Guid planId, Guid employeeId)
        {
            var plan = await _db.OnboardingPlans
                .Include(p => p.Tasks)
                .FirstOrDefaultAsync(p => p.Id == planId)
                ?? throw new KeyNotFoundException("Plan not found");

            var employee = await _db.Employees.FindAsync(employeeId)
                ?? throw new KeyNotFoundException("Employee not found");

            var existing = await _db.TaskAssignments.Where(a => a.EmployeeId == employeeId).ToListAsync();
            _db.TaskAssignments.RemoveRange(existing);

            var assignments = plan.Tasks.Select(task => new TaskAssignment
            {
                EmployeeId = employeeId,
                TaskId = task.Id,
                Status = AssignmentStatus.Pending
            }).ToList();

            await _db.TaskAssignments.AddRangeAsync(assignments);

            var checkpoints = new[]
            {
            new OnboardingCheckpoint { EmployeeId = employeeId, Title = "30-Day Check-in", WeekNumber = 4 },
            new OnboardingCheckpoint { EmployeeId = employeeId, Title = "60-Day Review", WeekNumber = 8 },
            new OnboardingCheckpoint { EmployeeId = employeeId, Title = "90-Day Completion", WeekNumber = 12 }
        };
            await _db.OnboardingCheckpoints.AddRangeAsync(checkpoints);

            employee.OnboardingStatus = OnboardingStatus.InProgress;
            await _db.SaveChangesAsync();

            await _notifications.SendAsync(
                employeeId,
                "Onboarding Plan Assigned",
                $"Your onboarding plan '{plan.Title}' is ready. You have {plan.Tasks.Count} tasks to complete.",
                NotificationType.TaskAssigned
            );
        }

        public async Task<List<CheckpointDto>> GetCheckpointsAsync(Guid employeeId)
        {
            var checkpoints = await _db.OnboardingCheckpoints
                .AsNoTracking()
                .Where(c => c.EmployeeId == employeeId)
                .OrderBy(c => c.WeekNumber)
                .ToListAsync();

            return checkpoints.Select(c => new CheckpointDto(
                c.Id, c.Title, c.WeekNumber, c.IsCompleted,
                c.CompletedAt, c.HrFeedback, c.SatisfactionScore
            )).ToList();
        }

        public async Task<CheckpointDto> CompleteCheckpointAsync(Guid checkpointId, CompleteCheckpointRequest request)
        {
            var checkpoint = await _db.OnboardingCheckpoints.FindAsync(checkpointId)
                ?? throw new KeyNotFoundException("Checkpoint not found");

            checkpoint.IsCompleted = true;
            checkpoint.CompletedAt = DateTime.UtcNow;
            checkpoint.HrFeedback = request.HrFeedback;
            checkpoint.SatisfactionScore = request.SatisfactionScore;

            await _db.SaveChangesAsync();

            return new CheckpointDto(
                checkpoint.Id, checkpoint.Title, checkpoint.WeekNumber,
                checkpoint.IsCompleted, checkpoint.CompletedAt,
                checkpoint.HrFeedback, checkpoint.SatisfactionScore
            );
        }

        public async Task<int> CalculateProgressAsync(Guid employeeId)
        {
            var total = await _db.TaskAssignments.CountAsync(a => a.EmployeeId == employeeId);
            if (total == 0) return 0;
            var completed = await _db.TaskAssignments.CountAsync(a =>
                a.EmployeeId == employeeId && a.Status == AssignmentStatus.Completed);
            return (int)Math.Round((double)completed / total * 100);
        }

        private static OnboardingStatus DetermineStatus(int progress, DateTime hireDate)
        {
            var daysSinceHire = (DateTime.UtcNow - hireDate).Days;
            var expectedProgress = Math.Min(100, (int)(daysSinceHire / 90.0 * 100));

            if (progress >= 100) return OnboardingStatus.Completed;
            if (progress >= expectedProgress - 10) return OnboardingStatus.OnTrack;
            if (progress < expectedProgress - 25) return OnboardingStatus.AtRisk;
            return OnboardingStatus.InProgress;
        }

        private static TaskAssignmentDto MapAssignment(TaskAssignment a) => new(
            a.Id,
            new OnboardingTaskDto(
                a.Task.Id, a.Task.Title, a.Task.Description, a.Task.Category,
                a.Task.DayNumber, a.Task.EstimatedMinutes, a.Task.Priority,
                a.Task.IsRequired, a.Task.ResourceUrl
            ),
            a.Status, a.CompletedAt, a.Notes, a.Score
        );

        private static OnboardingPlanDto MapPlan(OnboardingPlan p) => new(
            p.Id, p.Title, p.Description, p.Department, p.Position, p.DurationDays,
            p.Tasks.Select(t => new OnboardingTaskDto(
                t.Id, t.Title, t.Description, t.Category, t.DayNumber,
                t.EstimatedMinutes, t.Priority, t.IsRequired, t.ResourceUrl
            )).ToList()
        );
    }
}
