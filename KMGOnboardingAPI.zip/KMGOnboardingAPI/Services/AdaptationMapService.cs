﻿using KMGOnboardingAPI.Data;
using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.DTOs.AI;
using KMGOnboardingAPI.DTOs.Week;
using KMGOnboardingAPI.Interfaces;
using KMGOnboardingAPI.Models.Entities;
using KMGOnboardingAPI.Models.Enums;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace KMGOnboardingAPI.Services
{
    public class AdaptationMapService : IAdaptationMapService
    {
        private readonly AppDbContext _db;
        private readonly IAiService _ai;
        private readonly INotificationService _notifications;
        private readonly ILogger<AdaptationMapService> _logger;

        private static readonly List<DefaultMilestone> DEFAULT_MILESTONES = new()
    {
        new("Welcome & Orientation Complete", "You have completed the initial orientation and know your way around the office.", 3, MilestoneType.Orientation, 1),
        new("All Systems Access Granted", "SAP, email, VPN, and required systems are fully set up and working.", 7, MilestoneType.SystemsSetup, 2),
        new("HSE Safety Certified", "Health, Safety & Environment induction completed and certified.", 10, MilestoneType.SafetyCertified, 3),
        new("Team Integration", "Met key colleagues and know who to go to for what.", 14, MilestoneType.TeamIntegration, 4),
        new("First Independent Task", "Completed your first task with minimal guidance.", 21, MilestoneType.FirstProject, 5),
        new("Compliance Training Done", "All mandatory compliance and ethics e-learnings completed.", 30, MilestoneType.ComplianceDone, 6),
        new("Month 1 Check-in Passed", "Successfully completed your 30-day performance check-in with HR.", 30, MilestoneType.Custom, 7),
        new("Working Independently", "Handling day-to-day responsibilities without regular hand-holding.", 60, MilestoneType.IndependentWork, 8),
        new("90-Day Probation Complete", "You have officially completed your probation period at KazMunaiGas.", 90, MilestoneType.ProbationComplete, 9),
    };

        public AdaptationMapService(
            AppDbContext db,
            IAiService ai,
            INotificationService notifications,
            ILogger<AdaptationMapService> logger)
        {
            _db = db;
            _ai = ai;
            _notifications = notifications;
            _logger = logger;
        }

        public async Task<AdaptationMapDto> GetMapAsync(Guid employeeId)
        {
            var milestones = await _db.AdaptationMilestones
                .Where(m => m.EmployeeId == employeeId)
                .OrderBy(m => m.Order)
                .ToListAsync();

            if (!milestones.Any())
                return await InitializeMapAsync(employeeId);

            return await BuildMapDtoAsync(employeeId, milestones);
        }

        public async Task<AdaptationMapDto> InitializeMapAsync(Guid employeeId)
        {
            var employee = await _db.Employees.FindAsync(employeeId)
                ?? throw new KeyNotFoundException("Employee not found");

            var existing = await _db.AdaptationMilestones.AnyAsync(m => m.EmployeeId == employeeId);
            if (existing)
            {
                var existingMilestones = await _db.AdaptationMilestones
                    .Where(m => m.EmployeeId == employeeId)
                    .OrderBy(m => m.Order)
                    .ToListAsync();
                return await BuildMapDtoAsync(employeeId, existingMilestones);
            }

            var milestones = DEFAULT_MILESTONES.Select(d => new AdaptationMilestone
            {
                EmployeeId = employeeId,
                Title = d.Title,
                Description = d.Description,
                DayNumber = d.DayNumber,
                MilestoneType = d.Type,
                Order = d.Order,
                IsCompleted = false
            }).ToList();

            var daysOnboarding = (DateTime.UtcNow - employee.HireDate).Days;
            foreach (var m in milestones.Where(m => m.DayNumber <= daysOnboarding))
            {
                m.IsCompleted = true;
                m.CompletedAt = employee.HireDate.AddDays(m.DayNumber);
            }

            await _db.AdaptationMilestones.AddRangeAsync(milestones);
            await _db.SaveChangesAsync();

            await _notifications.SendAsync(
                employeeId,
                "Your 90-Day Journey Map is ready",
                "Check your adaptation map to see your progress and upcoming milestones.",
                NotificationType.AiInsightReady
            );

            return await BuildMapDtoAsync(employeeId, milestones);
        }

        public async Task<MilestoneDto> CompleteMilestoneAsync(Guid milestoneId, Guid requestingEmployeeId)
        {
            var milestone = await _db.AdaptationMilestones
                .Include(m => m.Employee)
                .FirstOrDefaultAsync(m => m.Id == milestoneId)
                ?? throw new KeyNotFoundException("Milestone not found");

            if (milestone.EmployeeId != requestingEmployeeId)
            {
                var requester = await _db.Employees.FindAsync(requestingEmployeeId);
                if (requester?.Role is not (EmployeeRole.HrManager or EmployeeRole.Admin or EmployeeRole.Manager))
                    throw new UnauthorizedAccessException("Not authorized to complete this milestone");
            }

            milestone.IsCompleted = true;
            milestone.CompletedAt = DateTime.UtcNow;

            var prompt = $"""
            Write a brief, warm congratulatory note (2 sentences) for a KMG employee who just completed this onboarding milestone:
            Milestone: {milestone.Title}
            Employee: {milestone.Employee.FirstName}, {milestone.Employee.Position}
            Day {(int)(DateTime.UtcNow - milestone.Employee.HireDate).TotalDays} of their onboarding
            Be genuine and specific to the milestone. No corporate speak.
            """;

            var aiNote = await _ai.ChatAsync(new AiChatRequest(prompt));
            milestone.AiNote = aiNote.Reply;

            await _db.SaveChangesAsync();

            await _notifications.SendAsync(
                milestone.EmployeeId,
                $"Milestone achieved: {milestone.Title}",
                milestone.AiNote ?? "Congratulations on reaching this milestone!",
                NotificationType.AiInsightReady
            );

            var currentDay = (int)(DateTime.UtcNow - milestone.Employee.HireDate).TotalDays;
            return new MilestoneDto(
                milestone.Id, milestone.Title, milestone.Description,
                milestone.DayNumber, milestone.MilestoneType.ToString(),
                milestone.IsCompleted, milestone.CompletedAt, milestone.AiNote,
                milestone.Order, false, false
            );
        }

        public async Task<WeeklyPlanDto> GetOrGenerateWeeklyPlanAsync(Guid employeeId, int? weekNumber = null)
        {
            var employee = await _db.Employees
                .Include(e => e.TaskAssignments).ThenInclude(t => t.Task)
                .Include(e => e.Checkpoints)
                .FirstOrDefaultAsync(e => e.Id == employeeId)
                ?? throw new KeyNotFoundException("Employee not found");

            var currentWeek = weekNumber ?? (int)Math.Ceiling((DateTime.UtcNow - employee.HireDate).TotalDays / 7.0);
            currentWeek = Math.Max(1, currentWeek);

            var existing = await _db.WeeklyPlans
                .FirstOrDefaultAsync(p => p.EmployeeId == employeeId && p.WeekNumber == currentWeek);

            if (existing != null)
                return MapWeeklyPlanToDto(existing);

            return await GenerateWeeklyPlanAsync(employee, currentWeek);
        }

        private async Task<WeeklyPlanDto> GenerateWeeklyPlanAsync(Employee employee, int weekNumber)
        {
            var pendingTasks = employee.TaskAssignments
                .Where(t => t.Status == AssignmentStatus.Pending || t.Status == AssignmentStatus.InProgress)
                .OrderBy(t => t.Task.Priority)
                .Take(5)
                .Select(t => t.Task.Title)
                .ToList();

            var completedThisWeek = employee.TaskAssignments
                .Count(t => t.Status == AssignmentStatus.Completed &&
                            t.CompletedAt >= DateTime.UtcNow.AddDays(-7));

            var overdueCount = employee.TaskAssignments
                .Count(t => t.Status == AssignmentStatus.Overdue);

            var upcomingMilestones = await _db.AdaptationMilestones
                .Where(m => m.EmployeeId == employee.Id && !m.IsCompleted &&
                            m.DayNumber <= (DateTime.UtcNow - employee.HireDate).TotalDays + 14)
                .OrderBy(m => m.DayNumber)
                .Take(2)
                .Select(m => m.Title)
                .ToListAsync();

            var prompt = $"""
            Create a personalized weekly onboarding plan for a KMG employee.
            Make it realistic, warm, and actionable. Speak directly to them.

            Employee: {employee.FirstName} {employee.LastName}
            Position: {employee.Position}, {employee.Department}
            Week number: {weekNumber} of their onboarding
            Completed tasks this week: {completedThisWeek}
            Overdue tasks: {overdueCount}
            Pending tasks: {string.Join(", ", pendingTasks.Take(3))}
            Upcoming milestones: {string.Join(", ", upcomingMilestones)}

            Return ONLY this JSON (no markdown):
            
    
              "focus": "One sentence describing this week's theme (e.g., 'Building your safety knowledge')",
              "plan": "3-4 paragraphs: overview of the week, specific suggestions, one encouragement. Use {employee.FirstName}'s first name naturally.",
              "goals": ["goal 1", "goal 2", "goal 3", "goal 4", "goal 5"]
            
            """;

            var response = await _ai.ChatAsync(new AiChatRequest(prompt));

            string focus = "Building momentum this week";
            string plan = response.Reply;
            var goals = pendingTasks.Take(5).ToList();

            try
            {
                var clean = response.Reply.Trim().TrimStart('`').TrimEnd('`');
                if (clean.StartsWith("json", StringComparison.OrdinalIgnoreCase))
                    clean = clean[4..].Trim();

                using var doc = JsonDocument.Parse(clean);
                var root = doc.RootElement;

                focus = root.GetProperty("focus").GetString() ?? focus;
                plan = root.GetProperty("plan").GetString() ?? plan;
                goals = root.GetProperty("goals").EnumerateArray()
                    .Select(g => g.GetString() ?? "")
                    .Where(g => g.Length > 0)
                    .ToList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to parse weekly plan JSON, using raw response");
            }

            var weeklyPlan = new WeeklyPlan
            {
                EmployeeId = employee.Id,
                WeekNumber = weekNumber,
                Focus = focus,
                AiGeneratedPlan = plan,
                Goals = goals,
                GeneratedAt = DateTime.UtcNow,
                IsAcknowledged = false
            };

            await _db.WeeklyPlans.AddAsync(weeklyPlan);
            await _db.SaveChangesAsync();

            await _notifications.SendAsync(
                employee.Id,
                $"Your Week {weekNumber} plan is ready",
                $"Focus: {focus}",
                NotificationType.AiInsightReady
            );

            return MapWeeklyPlanToDto(weeklyPlan);
        }

        public async Task<WeeklyPlanDto> AcknowledgeWeeklyPlanAsync(Guid planId, Guid employeeId)
        {
            var plan = await _db.WeeklyPlans.FindAsync(planId)
                ?? throw new KeyNotFoundException("Plan not found");

            if (plan.EmployeeId != employeeId)
                throw new UnauthorizedAccessException();

            plan.IsAcknowledged = true;
            await _db.SaveChangesAsync();
            return MapWeeklyPlanToDto(plan);
        }

        public async Task RunWeeklyPlanGenerationAsync()
        {
            if (DateTime.UtcNow.DayOfWeek != DayOfWeek.Sunday) return;

            var activeEmployees = await _db.Employees
                .Where(e => e.OnboardingStatus == OnboardingStatus.InProgress ||
                            e.OnboardingStatus == OnboardingStatus.OnTrack)
                .ToListAsync();

            _logger.LogInformation("Generating Sunday weekly plans for {Count} employees", activeEmployees.Count);

            foreach (var employee in activeEmployees)
            {
                try
                {
                    var weekNumber = (int)Math.Ceiling((DateTime.UtcNow - employee.HireDate).TotalDays / 7.0) + 1;
                    await GenerateWeeklyPlanAsync(employee, weekNumber);
                    await Task.Delay(800);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error generating weekly plan for employee {Id}", employee.Id);
                }
            }
        }

        private async Task<AdaptationMapDto> BuildMapDtoAsync(Guid employeeId, List<AdaptationMilestone> milestones)
        {
            var employee = await _db.Employees.FindAsync(employeeId)
                ?? throw new KeyNotFoundException("Employee not found");

            var totalDays = 90;
            var daysOnboarding = Math.Min((int)(DateTime.UtcNow - employee.HireDate).TotalDays, totalDays);
            var progressPercent = Math.Round((double)daysOnboarding / totalDays * 100, 1);

            var nextMilestone = milestones.FirstOrDefault(m => !m.IsCompleted);
            var daysToNext = nextMilestone != null
                ? Math.Max(0, nextMilestone.DayNumber - daysOnboarding)
                : 0;

            var currentPhase = daysOnboarding switch
            {
                <= 7 => "First Week — Getting Settled",
                <= 30 => "Month 1 — Learning the Ropes",
                <= 60 => "Month 2 — Building Confidence",
                _ => "Month 3 — Becoming Independent"
            };

            var milestoneDtos = milestones.Select(m => new MilestoneDto(
                m.Id, m.Title, m.Description, m.DayNumber, m.MilestoneType.ToString(),
                m.IsCompleted, m.CompletedAt, m.AiNote, m.Order,
                IsCurrent: !m.IsCompleted && m.DayNumber <= daysOnboarding + 7,
                IsUpcoming: !m.IsCompleted && m.DayNumber > daysOnboarding + 7
            )).ToList();

            var currentWeekPlan = await _db.WeeklyPlans
                .Where(p => p.EmployeeId == employeeId)
                .OrderByDescending(p => p.WeekNumber)
                .FirstOrDefaultAsync();

            return new AdaptationMapDto(
                employeeId,
                $"{employee.FirstName} {employee.LastName}",
                employee.HireDate,
                daysOnboarding,
                totalDays,
                progressPercent,
                daysOnboarding,
                milestoneDtos,
                currentWeekPlan != null ? MapWeeklyPlanToDto(currentWeekPlan) : null,
                currentPhase,
                nextMilestone?.Title ?? "Congratulations — 90 days complete!",
                daysToNext
            );
        }

        private static WeeklyPlanDto MapWeeklyPlanToDto(WeeklyPlan p) => new(
            p.Id,
            p.WeekNumber,
            p.AiGeneratedPlan,
            p.Focus,
            p.Goals ?? new List<string>(),
            p.GeneratedAt,
            p.IsAcknowledged
        );

        private record DefaultMilestone(string Title, string Description, int DayNumber, MilestoneType Type, int Order);
    }
}
