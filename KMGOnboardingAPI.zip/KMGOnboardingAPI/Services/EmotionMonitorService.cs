﻿using KMGOnboardingAPI.Data;
using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.DTOs.AI;
using KMGOnboardingAPI.Interfaces;
using KMGOnboardingAPI.Models.Entities;
using KMGOnboardingAPI.Models.Enums;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace KMGOnboardingAPI.Services
{
    public class EmotionMonitorService : IEmotionMonitorService
    {
        private readonly AppDbContext _db;
        private readonly IAiService _ai;
        private readonly INotificationService _notifications;
        private readonly IMeetingService _meetings;
        private readonly ILogger<EmotionMonitorService> _logger;
        private readonly IEmailDigestService _emailDigest;

        private static readonly double BURNOUT_ALERT_THRESHOLD = 0.65;
        private static readonly int ANALYSIS_WINDOW_HOURS = 72;
        private static readonly int MIN_MESSAGES_FOR_ANALYSIS = 3;

        public EmotionMonitorService(
            AppDbContext db,
            IAiService ai,
            INotificationService notifications,
            IMeetingService meetings,
            IEmailDigestService emailDigest,
            ILogger<EmotionMonitorService> logger)
        {
            _db = db;
            _ai = ai;
            _notifications = notifications;
            _meetings = meetings;
            _emailDigest = emailDigest;
            _logger = logger;
        }

        public async Task<EmotionSnapshotDto> AnalyzeEmployeeAsync(Guid employeeId)
        {
            var employee = await _db.Employees
                .Include(e => e.TaskAssignments).ThenInclude(t => t.Task)
                .FirstOrDefaultAsync(e => e.Id == employeeId)
                ?? throw new KeyNotFoundException("Employee not found");

            var windowStart = DateTime.UtcNow.AddHours(-ANALYSIS_WINDOW_HOURS);
            var windowEnd = DateTime.UtcNow;

            var recentMessages = await _db.ChatMessages
                .Where(m => m.SenderId == employeeId && m.CreatedAt >= windowStart)
                .OrderByDescending(m => m.CreatedAt)
                .Take(50)
                .Select(m => m.Content)
                .ToListAsync();

            var taskNotes = await _db.TaskAssignments
                .Where(t => t.EmployeeId == employeeId && t.Notes != null && t.UpdatedAt >= windowStart)
                .Select(t => t.Notes!)
                .ToListAsync();

            var overdueTasks = await _db.TaskAssignments
                .CountAsync(t => t.EmployeeId == employeeId && t.Status == AssignmentStatus.Overdue);

            var daysOnboarding = (DateTime.UtcNow - employee.HireDate).Days;

            if (recentMessages.Count + taskNotes.Count < MIN_MESSAGES_FOR_ANALYSIS)
            {
                return CreateDefaultSnapshot(employee, windowStart, windowEnd, recentMessages.Count + taskNotes.Count);
            }

            var analysisResult = await CallGeminiEmotionAnalysisAsync(
                employee, recentMessages, taskNotes, overdueTasks, daysOnboarding);

            var snapshot = new EmotionSnapshot
            {
                EmployeeId = employeeId,
                OverallTone = ParseEmotionTone(analysisResult.Tone),
                BurnoutRisk = analysisResult.BurnoutRisk,
                StressLevel = analysisResult.StressLevel,
                EngagementLevel = analysisResult.EngagementLevel,
                Signals = JsonSerializer.Serialize(analysisResult.Signals),
                AiAdvice = analysisResult.PersonalizedAdvice,
                MessagesAnalyzed = recentMessages.Count,
                TaskNotesAnalyzed = taskNotes.Count,
                WindowStart = windowStart,
                WindowEnd = windowEnd,
                HrAlertSent = false
            };

            await _db.EmotionSnapshots.AddAsync(snapshot);
            await _db.SaveChangesAsync();

            if (analysisResult.BurnoutRisk >= BURNOUT_ALERT_THRESHOLD)
            {
                await TriggerBurnoutInterventionAsync(employee, snapshot, analysisResult);
                snapshot.HrAlertSent = true;
                await _db.SaveChangesAsync();
            }

            await _notifications.SendAsync(
                employeeId,
                "Your wellness check is ready",
                analysisResult.PersonalizedAdvice.Length > 100
                    ? analysisResult.PersonalizedAdvice[..100] + "..."
                    : analysisResult.PersonalizedAdvice,
                NotificationType.AiInsightReady
            );

            return MapToDto(snapshot, employee);
        }

        private async Task<GeminiEmotionResult> CallGeminiEmotionAnalysisAsync(
            Employee employee,
            List<string> messages,
            List<string> taskNotes,
            int overdueTasks,
            int daysOnboarding)
        {
            var messagesText = messages.Count > 0
                ? string.Join("\n", messages.Take(20).Select((m, i) => $"[{i + 1}] {m}"))
                : "No recent messages";

            var notesText = taskNotes.Count > 0
                ? string.Join("\n", taskNotes.Take(10).Select((n, i) => $"[{i + 1}] {n}"))
                : "No task notes";

            var prompt = $"""
            You are a corporate wellness AI for KazMunaiGas HR system.
            Analyze this employee's recent communications for emotional wellbeing signals.
            Be compassionate and avoid alarmism. Focus on patterns, not single messages.

            Employee context:
            - Name: {employee.FirstName} {employee.LastName}
            - Position: {employee.Position}
            - Department: {employee.Department}
            - Days since joining: {daysOnboarding}
            - Overdue tasks: {overdueTasks}
            - Onboarding progress: {employee.OnboardingProgress}%

            Recent chat messages (last 72 hours):
            {messagesText}

            Task completion notes:
            {notesText}

            Return ONLY this JSON (no markdown):
            
    
              "tone": "Positive|Neutral|Stressed|Disengaged|Burnout|Overwhelmed",
              "burnoutRisk": 0.0-1.0,
              "stressLevel": 0.0-1.0,
              "engagementLevel": 0.0-1.0,
              "signals": ["signal1", "signal2", "signal3"],
              "personalizedAdvice": "2-3 warm, actionable sentences directly to the employee. Use their first name.",
              "hrRecommendation": "1-2 sentences for the HR manager about this employee (professional tone)"
            
            """;

            var response = await _ai.ChatAsync(new AiChatRequest(prompt));

            try
            {
                var clean = response.Reply.Trim().TrimStart('`').TrimEnd('`');
                if (clean.StartsWith("json", StringComparison.OrdinalIgnoreCase))
                    clean = clean[4..].Trim();

                using var doc = JsonDocument.Parse(clean);
                var root = doc.RootElement;

                return new GeminiEmotionResult
                {
                    Tone = root.GetProperty("tone").GetString() ?? "Neutral",
                    BurnoutRisk = Clamp(root.GetProperty("burnoutRisk").GetDouble()),
                    StressLevel = Clamp(root.GetProperty("stressLevel").GetDouble()),
                    EngagementLevel = Clamp(root.GetProperty("engagementLevel").GetDouble()),
                    Signals = root.GetProperty("signals").EnumerateArray()
                        .Select(s => s.GetString() ?? "")
                        .Where(s => s.Length > 0)
                        .ToList(),
                    PersonalizedAdvice = root.GetProperty("personalizedAdvice").GetString() ?? "",
                    HrRecommendation = root.GetProperty("hrRecommendation").GetString() ?? ""
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to parse Gemini emotion response for employee {Id}", employee.Id);
                return new GeminiEmotionResult
                {
                    Tone = "Neutral",
                    BurnoutRisk = 0.3,
                    StressLevel = 0.3,
                    EngagementLevel = 0.6,
                    Signals = new List<string> { "Insufficient data for detailed analysis" },
                    PersonalizedAdvice = $"Hi {employee.FirstName}, keep up the good work with your onboarding!",
                    HrRecommendation = "Standard check-in recommended."
                };
            }
        }

        private async Task TriggerBurnoutInterventionAsync(
            Employee employee,
            EmotionSnapshot snapshot,
            GeminiEmotionResult result)
        {
            var hrManagers = await _db.Employees
                .Where(e => e.Role == EmployeeRole.HrManager || e.Role == EmployeeRole.Admin)
                .ToListAsync();

            foreach (var hr in hrManagers)
            {
                await _notifications.SendAsync(
                    hr.Id,
                    $"Wellness Alert: {employee.FirstName} {employee.LastName}",
                    $"Burnout risk detected ({snapshot.BurnoutRisk:P0}). {result.HrRecommendation}",
                    NotificationType.AiInsightReady,
                    $"/employees/{employee.Id}/wellness"
                );
            }

            var meetingStart = DateTime.UtcNow.AddDays(1).Date.AddHours(10);
            if (hrManagers.Any())
            {
                await _meetings.CreateAsync(new CreateMeetingRequest(
                    Title: $"Wellness check-in — {employee.FirstName} {employee.LastName}",
                    Description: $"Auto-scheduled by KMG Wellness Monitor. AI signals: {string.Join(", ", result.Signals.Take(3))}. Recommendation: {result.HrRecommendation}",
                    StartTime: meetingStart,
                    EndTime: meetingStart.AddMinutes(30),
                    MeetingUrl: null,
                    Location: "HR Office or Teams",
                    MeetingType: MeetingType.CheckIn,
                    ParticipantIds: new List<Guid> { employee.Id, hrManagers.First().Id }
                ), hrManagers.First().Id);
            }

            _logger.LogWarning(
                "Burnout alert triggered for employee {Id} ({Name}). Risk: {Risk:P0}",
                employee.Id, $"{employee.FirstName} {employee.LastName}", snapshot.BurnoutRisk);

            _ = Task.Run(async () => await _emailDigest.SendBurnoutAlertEmailAsync(
                employee.Id,
                snapshot.BurnoutRisk,
                string.Join(", ", result.Signals)
            ));
        }

        public async Task<EmotionDashboardDto> GetHrDashboardAsync()
        {
            var cutoff = DateTime.UtcNow.AddDays(-7);
            var recentSnapshots = await _db.EmotionSnapshots
                .Include(s => s.Employee)
                .Where(s => s.CreatedAt >= cutoff)
                .GroupBy(s => s.EmployeeId)
                .Select(g => g.OrderByDescending(s => s.CreatedAt).First())
                .ToListAsync();

            var atRisk = recentSnapshots
                .Where(s => s.BurnoutRisk >= 0.5)
                .OrderByDescending(s => s.BurnoutRisk)
                .Select(s => MapToDto(s, s.Employee))
                .ToList();

            var avgBurnout = recentSnapshots.Any()
                ? Math.Round(recentSnapshots.Average(s => s.BurnoutRisk), 3)
                : 0;
            var avgEngagement = recentSnapshots.Any()
                ? Math.Round(recentSnapshots.Average(s => s.EngagementLevel), 3)
                : 0;

            var totalAlerts = await _db.EmotionSnapshots
                .CountAsync(s => s.HrAlertSent && s.CreatedAt >= cutoff);

            var toneDistribution = recentSnapshots
                .GroupBy(s => s.OverallTone.ToString())
                .ToDictionary(g => g.Key, g => g.Count());

            return new EmotionDashboardDto(atRisk, avgBurnout, avgEngagement, totalAlerts, toneDistribution);
        }

        public async Task<List<EmotionSnapshotDto>> GetEmployeeHistoryAsync(Guid employeeId, int days = 30)
        {
            var cutoff = DateTime.UtcNow.AddDays(-days);
            var employee = await _db.Employees.FindAsync(employeeId)
                ?? throw new KeyNotFoundException("Employee not found");

            return await _db.EmotionSnapshots
                .Where(s => s.EmployeeId == employeeId && s.CreatedAt >= cutoff)
                .OrderByDescending(s => s.CreatedAt)
                .Select(s => MapToDto(s, employee))
                .ToListAsync();
        }

        public async Task RunScheduledAnalysisAsync()
        {
            var activeEmployees = await _db.Employees
                .Where(e => e.OnboardingStatus == OnboardingStatus.InProgress ||
                            e.OnboardingStatus == OnboardingStatus.OnTrack ||
                            e.OnboardingStatus == OnboardingStatus.AtRisk)
                .Select(e => e.Id)
                .ToListAsync();

            _logger.LogInformation("Running scheduled emotion analysis for {Count} employees", activeEmployees.Count);

            foreach (var employeeId in activeEmployees)
            {
                try
                {
                    await AnalyzeEmployeeAsync(employeeId);
                    await Task.Delay(500);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error analyzing employee {Id}", employeeId);
                }
            }
        }

        private EmotionSnapshotDto CreateDefaultSnapshot(Employee employee, DateTime start, DateTime end, int dataPoints)
        {
            return new EmotionSnapshotDto(
                Guid.NewGuid(),
                employee.Id,
                $"{employee.FirstName} {employee.LastName}",
                "Neutral",
                0.2,
                0.2,
                0.7,
                new List<string> { $"Only {dataPoints} data points available — check back in a few days" },
                $"Hi {employee.FirstName}, we need a bit more activity data to give you personalized insights. Keep engaging with your tasks and colleagues!",
                false,
                dataPoints,
                start,
                end,
                DateTime.UtcNow
            );
        }

        private static EmotionSnapshotDto MapToDto(EmotionSnapshot s, Employee e)
        {
            List<string> signals;
            try { signals = JsonSerializer.Deserialize<List<string>>(s.Signals) ?? new List<string>(); }
            catch { signals = new List<string> { s.Signals }; }

            return new EmotionSnapshotDto(
                s.Id,
                s.EmployeeId,
                $"{e.FirstName} {e.LastName}",
                s.OverallTone.ToString(),
                Math.Round(s.BurnoutRisk, 3),
                Math.Round(s.StressLevel, 3),
                Math.Round(s.EngagementLevel, 3),
                signals,
                s.AiAdvice,
                s.HrAlertSent,
                s.MessagesAnalyzed,
                s.WindowStart,
                s.WindowEnd,
                s.CreatedAt
            );
        }

        private static EmotionTone ParseEmotionTone(string tone) =>
            Enum.TryParse<EmotionTone>(tone, true, out var result) ? result : EmotionTone.Neutral;

        private static double Clamp(double value) => Math.Max(0.0, Math.Min(1.0, value));

        private record GeminiEmotionResult
        {
            public string Tone { get; init; } = "Neutral";
            public double BurnoutRisk { get; init; }
            public double StressLevel { get; init; }
            public double EngagementLevel { get; init; }
            public List<string> Signals { get; init; } = new();
            public string PersonalizedAdvice { get; init; } = string.Empty;
            public string HrRecommendation { get; init; } = string.Empty;
        }
    }
}
