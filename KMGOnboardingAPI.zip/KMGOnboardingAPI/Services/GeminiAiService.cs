﻿using KMGOnboardingAPI.Data;
using KMGOnboardingAPI.DTOs.AI;
using KMGOnboardingAPI.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Text;
using System.Text.Json;

namespace KMGOnboardingAPI.Services
{
    public class GeminiAiService : IAiService
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiKey;
        private readonly string _baseUrl;
        private readonly AppDbContext _db;
        private readonly ILogger<GeminiAiService> _logger;

        private const string KMG_SYSTEM_PROMPT = """
        You are an AI assistant for KazMunaiGas (KMG) HR Onboarding Platform. 
        KMG is Kazakhstan's national oil and gas company. You help new employees adapt to the corporate environment.
        
        Key principles:
        - Be professional, warm, and encouraging
        - Understand cultural nuances of Kazakhstan workplace
        - Know KMG values: safety first, teamwork, integrity, innovation
        - Help with onboarding tasks, company policies, career guidance
        - Support in Kazakh, Russian, and English languages
        - Be aware of oil & gas industry specifics
        - Never share sensitive company data
        - Mental health awareness: recognize stress signs in new employees
        - Promote work-life balance per KMG wellness programs
        
        When answering, be concise, practical, and human. No jargon.
        """;

        public GeminiAiService(IConfiguration config, AppDbContext db, ILogger<GeminiAiService> logger, IHttpClientFactory httpClientFactory)
        {
            _apiKey = config["Gemini:ApiKey"] ?? throw new InvalidOperationException("Gemini API key not configured");
            _baseUrl = config["Gemini:BaseUrl"] ?? "https://generativelanguage.googleapis.com/v1beta";
            _db = db;
            _logger = logger;
            _httpClient = httpClientFactory.CreateClient("gemini");
        }

        public async Task<AiChatResponse> ChatAsync(AiChatRequest request, string? employeeContext = null)
        {
            try
            {
                var contents = new List<object>();

                if (request.History != null)
                {
                    foreach (var h in request.History)
                    {
                        contents.Add(new { role = h.Role, parts = new[] { new { text = h.Content } } });
                    }
                }

                var userMessage = employeeContext != null
                    ? $"[Employee Context: {employeeContext}]\n\n{request.Message}"
                    : request.Message;

                contents.Add(new { role = "user", parts = new[] { new { text = userMessage } } });

                var body = new
                {
                    system_instruction = new { parts = new[] { new { text = KMG_SYSTEM_PROMPT } } },
                    contents,
                    generationConfig = new
                    {
                        temperature = 0.7,
                        topP = 0.8,
                        topK = 40,
                        maxOutputTokens = 2048,
                        stopSequences = Array.Empty<string>()
                    },
                    safetySettings = new[]
                    {
                    new { category = "HARM_CATEGORY_HARASSMENT", threshold = "BLOCK_MEDIUM_AND_ABOVE" },
                    new { category = "HARM_CATEGORY_HATE_SPEECH", threshold = "BLOCK_MEDIUM_AND_ABOVE" }
                }
                };

                var json = JsonSerializer.Serialize(body);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var url = $"{_baseUrl}/models/gemini-2.0-flash:generateContent?key={_apiKey}";

                var response = await _httpClient.PostAsync(url, content);
                var responseJson = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError("Gemini API error: {Status} - {Body}", response.StatusCode, responseJson);
                    return new AiChatResponse("I'm temporarily unavailable. Please try again shortly.", true);
                }

                using var doc = JsonDocument.Parse(responseJson);
                var text = doc.RootElement
                    .GetProperty("candidates")[0]
                    .GetProperty("content")
                    .GetProperty("parts")[0]
                    .GetProperty("text")
                    .GetString() ?? "No response generated.";

                return new AiChatResponse(text);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error calling Gemini API");
                return new AiChatResponse("Something went wrong. Please try again.", true);
            }
        }

        public async Task<AiInsightDto> GenerateInsightAsync(Guid employeeId)
        {
            var employee = await _db.Employees
                .Include(e => e.TaskAssignments).ThenInclude(t => t.Task)
                .Include(e => e.Checkpoints)
                .FirstOrDefaultAsync(e => e.Id == employeeId);

            if (employee == null)
                throw new KeyNotFoundException("Employee not found");

            var completedTasks = employee.TaskAssignments.Count(t => t.Status == Models.Enums.AssignmentStatus.Completed);
            var totalTasks = employee.TaskAssignments.Count;
            var overdueTasks = employee.TaskAssignments.Count(t => t.Status == Models.Enums.AssignmentStatus.Overdue);
            var avgScore = employee.TaskAssignments.Where(t => t.Score.HasValue).Average(t => (double?)t.Score) ?? 0;
            var daysOnboarding = (DateTime.UtcNow - employee.HireDate).Days;

            var prompt = $"""
            Analyze this KMG employee's onboarding data and provide insights:
            
            Employee: {employee.FirstName} {employee.LastName}
            Position: {employee.Position}
            Department: {employee.Department}
            Days since hire: {daysOnboarding}
            Onboarding progress: {employee.OnboardingProgress}%
            Tasks completed: {completedTasks}/{totalTasks}
            Overdue tasks: {overdueTasks}
            Average task score: {avgScore:F1}/10
            Completed checkpoints: {employee.Checkpoints.Count(c => c.IsCompleted)}
            
            Provide a JSON response with these exact fields:
            
    
              "strengthsAnalysis": "2-3 sentences about what they're doing well",
              "riskFactors": "2-3 sentences about concerns or risks",
              "recommendations": "3-4 specific actionable recommendations",
              "engagementScore": 0.0-10.0,
              "retentionRisk": 0.0-1.0
            
            
            Return ONLY valid JSON, no markdown.
            """;

            var chatResponse = await ChatAsync(new AiChatRequest(prompt));

            try
            {
                var clean = chatResponse.Reply.Trim().TrimStart('`').TrimEnd('`');
                if (clean.StartsWith("json")) clean = clean[4..].Trim();

                using var doc = JsonDocument.Parse(clean);
                var root = doc.RootElement;

                var insight = new Models.Entities.AiInsight
                {
                    EmployeeId = employeeId,
                    StrengthsAnalysis = root.GetProperty("strengthsAnalysis").GetString() ?? "",
                    RiskFactors = root.GetProperty("riskFactors").GetString() ?? "",
                    Recommendations = root.GetProperty("recommendations").GetString() ?? "",
                    EngagementScore = root.GetProperty("engagementScore").GetDouble(),
                    RetentionRisk = root.GetProperty("retentionRisk").GetDouble(),
                    LastAnalyzedAt = DateTime.UtcNow
                };

                var existing = await _db.AiInsights.FirstOrDefaultAsync(x => x.EmployeeId == employeeId);
                if (existing != null)
                {
                    existing.StrengthsAnalysis = insight.StrengthsAnalysis;
                    existing.RiskFactors = insight.RiskFactors;
                    existing.Recommendations = insight.Recommendations;
                    existing.EngagementScore = insight.EngagementScore;
                    existing.RetentionRisk = insight.RetentionRisk;
                    existing.LastAnalyzedAt = DateTime.UtcNow;
                }
                else
                {
                    await _db.AiInsights.AddAsync(insight);
                }

                await _db.SaveChangesAsync();

                return new AiInsightDto(
                    employeeId,
                    insight.StrengthsAnalysis,
                    insight.RiskFactors,
                    insight.Recommendations,
                    insight.EngagementScore,
                    insight.RetentionRisk,
                    insight.LastAnalyzedAt
                );
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to parse Gemini insight response");
                throw;
            }
        }

        public async Task<string> SummarizeDocumentAsync(string documentContent)
        {
            var prompt = $"""
            Summarize this KMG corporate document in 3-5 bullet points.
            Focus on what a new employee needs to know.
            Be concise and practical.
            
            Document:
            {documentContent[..Math.Min(documentContent.Length, 8000)]}
            """;

            var response = await ChatAsync(new AiChatRequest(prompt));
            return response.Reply;
        }

        public async Task<string> GeneratePersonalizedWelcomeAsync(Guid employeeId)
        {
            var employee = await _db.Employees.FindAsync(employeeId);
            if (employee == null) return "Welcome to KazMunaiGas!";

            var prompt = $"""
            Write a warm, personalized welcome message for a new KMG employee.
            Keep it to 3-4 sentences. Be genuine and encouraging, not corporate.
            
            Employee: {employee.FirstName}
            Position: {employee.Position}
            Department: {employee.Department}
            Start date: {employee.HireDate:MMMM d, yyyy}
            """;

            var response = await ChatAsync(new AiChatRequest(prompt));
            return response.Reply;
        }

        public async Task<List<string>> SuggestTasksAsync(string department, string position)
        {
            var prompt = $"""
            List 10 essential onboarding tasks for a new {position} in the {department} department at KazMunaiGas.
            Return as JSON array of strings. Example: ["Task 1", "Task 2"]
            Focus on practical, specific tasks for the oil & gas industry context in Kazakhstan.
            Return ONLY the JSON array.
            """;

            var response = await ChatAsync(new AiChatRequest(prompt));

            try
            {
                var clean = response.Reply.Trim().TrimStart('`').TrimEnd('`');
                if (clean.StartsWith("json")) clean = clean[4..].Trim();
                return JsonSerializer.Deserialize<List<string>>(clean) ?? new List<string>();
            }
            catch
            {
                return new List<string> { "Complete safety training", "Setup system access", "Meet your team" };
            }
        }

        public async Task<string> TranslateToKazakhAsync(string text)
        {
            var prompt = $"Translate the following to Kazakh language (Қазақ тілі). Return only the translation:\n\n{text}";
            var response = await ChatAsync(new AiChatRequest(prompt));
            return response.Reply;
        }
    }
}
