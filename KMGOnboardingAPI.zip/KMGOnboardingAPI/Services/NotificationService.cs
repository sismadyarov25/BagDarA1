﻿using KMGOnboardingAPI.Data;
using KMGOnboardingAPI.DTOs;
using KMGOnboardingAPI.Hubs;
using KMGOnboardingAPI.Interfaces;
using KMGOnboardingAPI.Models.Entities;
using KMGOnboardingAPI.Models.Enums;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;

namespace KMGOnboardingAPI.Services
{
    public class NotificationService : INotificationService
    {
        private readonly AppDbContext _db;
        private readonly IHubContext<NotificationHub> _hubContext;

        public NotificationService(AppDbContext db, IHubContext<NotificationHub> hubContext)
        {
            _db = db;
            _hubContext = hubContext;
        }

        public async Task<List<NotificationDto>> GetForEmployeeAsync(Guid employeeId, bool unreadOnly = false)
        {
            var query = _db.Notifications.AsNoTracking().Where(n => n.EmployeeId == employeeId);
            if (unreadOnly) query = query.Where(n => !n.IsRead);

            return await query
                .OrderByDescending(n => n.CreatedAt)
                .Select(n => new NotificationDto(n.Id, n.Title, n.Body, n.Type, n.IsRead, n.CreatedAt, n.ActionUrl))
                .ToListAsync();
        }

        public async Task MarkAsReadAsync(Guid notificationId)
        {
            var n = await _db.Notifications.FindAsync(notificationId);
            if (n != null)
            {
                n.IsRead = true;
                n.ReadAt = DateTime.UtcNow;
                await _db.SaveChangesAsync();
            }
        }

        public async Task MarkAllAsReadAsync(Guid employeeId)
        {
            await _db.Notifications
                .Where(n => n.EmployeeId == employeeId && !n.IsRead)
                .ExecuteUpdateAsync(s => s
                    .SetProperty(n => n.IsRead, true)
                    .SetProperty(n => n.ReadAt, DateTime.UtcNow));
        }

        public async Task SendAsync(Guid employeeId, string title, string body, NotificationType type, string? actionUrl = null)
        {
            var notification = new Notification
            {
                EmployeeId = employeeId,
                Title = title,
                Body = body,
                Type = type,
                ActionUrl = actionUrl
            };

            await _db.Notifications.AddAsync(notification);
            await _db.SaveChangesAsync();

            var dto = new NotificationDto(notification.Id, title, body, type, false, notification.CreatedAt, actionUrl);
            await _hubContext.Clients.User(employeeId.ToString()).SendAsync("ReceiveNotification", dto);
        }

        public async Task SendToAllAsync(string title, string body, NotificationType type)
        {
            var employeeIds = await _db.Employees.Select(e => e.Id).ToListAsync();

            var notifications = employeeIds.Select(id => new Notification
            {
                EmployeeId = id,
                Title = title,
                Body = body,
                Type = type
            }).ToList();

            await _db.Notifications.AddRangeAsync(notifications);
            await _db.SaveChangesAsync();

            var dto = new NotificationDto(Guid.Empty, title, body, type, false, DateTime.UtcNow, null);
            await _hubContext.Clients.All.SendAsync("ReceiveNotification", dto);
        }
    }
}
