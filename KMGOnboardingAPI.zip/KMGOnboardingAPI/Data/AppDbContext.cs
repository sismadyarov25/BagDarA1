﻿using KMGOnboardingAPI.Models.Entities;
using KMGOnboardingAPI.Models.Entities.Base;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using KMGOnboardingAPI.Helpers;

namespace KMGOnboardingAPI.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<OnboardingPlan> OnboardingPlans { get; set; }
        public DbSet<OnboardingTask> OnboardingTasks { get; set; }
        public DbSet<TaskAssignment> TaskAssignments { get; set; }
        public DbSet<OnboardingCheckpoint> OnboardingCheckpoints { get; set; }
        public DbSet<ChatRoom> ChatRooms { get; set; }
        public DbSet<ChatRoomMember> ChatRoomMembers { get; set; }
        public DbSet<ChatMessage> ChatMessages { get; set; }
        public DbSet<MessageReaction> MessageReactions { get; set; }
        public DbSet<Document> Documents { get; set; }
        public DbSet<Notification> Notifications { get; set; }
        public DbSet<Meeting> Meetings { get; set; }
        public DbSet<MeetingParticipant> MeetingParticipants { get; set; }
        public DbSet<AiInsight> AiInsights { get; set; }
        public DbSet<SurveyTemplate> SurveyTemplates { get; set; }
        public DbSet<SurveyQuestion> SurveyQuestions { get; set; }
        public DbSet<SurveyResponse> SurveyResponses { get; set; }
        public DbSet<EmotionSnapshot> EmotionSnapshots { get; set; }
        public DbSet<AdaptationMilestone> AdaptationMilestones { get; set; }
        public DbSet<WeeklyPlan> WeeklyPlans { get; set; }
        public DbSet<MessageTranslation> MessageTranslations { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Employee>(e =>
            {
                e.HasIndex(x => x.Email).IsUnique();
                e.Property(x => x.Email).HasMaxLength(256);
                e.Property(x => x.FirstName).HasMaxLength(100);
                e.Property(x => x.LastName).HasMaxLength(100);
                e.Property(x => x.Position).HasMaxLength(200);
                e.Property(x => x.Department).HasMaxLength(200);
            });

            modelBuilder.Entity<TaskAssignment>(e =>
            {
                e.HasOne(x => x.Employee).WithMany(x => x.TaskAssignments)
                    .HasForeignKey(x => x.EmployeeId).OnDelete(DeleteBehavior.Restrict);

                e.HasOne(x => x.Task).WithMany(x => x.Assignments)
                    .HasForeignKey(x => x.TaskId).OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<ChatMessage>(e =>
            {
                e.HasOne(x => x.Sender).WithMany(x => x.SentMessages)
                    .HasForeignKey(x => x.SenderId).OnDelete(DeleteBehavior.Restrict);

                e.HasOne(x => x.ReplyTo).WithMany()
                    .HasForeignKey(x => x.ReplyToId).OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<AiInsight>(e =>
            {
                e.HasOne(x => x.Employee).WithOne(x => x.AiInsight)
                    .HasForeignKey<AiInsight>(x => x.EmployeeId);
            });

            modelBuilder.Entity<WeeklyPlan>(e =>
            {
                e.Property(x => x.Goals)
                    .HasConversion(
                        v => v == null ? null : JsonSerializer.Serialize(v, (JsonSerializerOptions?)null),
                        v => v == null ? null : JsonSerializer.Deserialize<List<string>>(v, (JsonSerializerOptions?)null)
                    );
            });

            modelBuilder.Entity<MessageTranslation>(e =>
            {
                e.HasIndex(x => new { x.MessageId, x.TargetLanguage }).IsUnique();
            });

            foreach (var entityType in modelBuilder.Model.GetEntityTypes())
            {
                if (typeof(BaseEntity).IsAssignableFrom(entityType.ClrType))
                {
                    modelBuilder.Entity(entityType.ClrType)
                        .HasQueryFilter(BuildIsDeleted.BuildIsDeletedFilter(entityType.ClrType));
                }
            }
        }
    }
}
