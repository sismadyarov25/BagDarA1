﻿using KMGOnboardingAPI.Models.Entities;
using KMGOnboardingAPI.Models.Enums;

namespace KMGOnboardingAPI.Data
{
    public class SeedData
    {
        public static async Task SeedAsync(AppDbContext db)
        {
            if (db.Employees.Any()) return;

            var hrManager = new Employee
            {
                Id = Guid.NewGuid(),
                FirstName = "Aizat",
                LastName = "Bekova",
                Email = "hr@kmg.kz",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("Admin123!"),
                Position = "HR Manager",
                Department = "Human Resources",
                HireDate = DateTime.UtcNow.AddYears(-3),
                Role = EmployeeRole.HrManager,
                OnboardingStatus = OnboardingStatus.Completed,
                OnboardingProgress = 100
            };

            var employees = new List<Employee>
        {
            new()
            {
                FirstName = "Dauren", LastName = "Seitkali",
                Email = "dauren.s@kmg.kz",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("Pass123!"),
                Position = "Petroleum Engineer", Department = "Upstream Operations",
                HireDate = DateTime.UtcNow.AddDays(-15),
                OnboardingStatus = OnboardingStatus.InProgress, OnboardingProgress = 42
            },
            new()
            {
                FirstName = "Madina", LastName = "Nurmagambetova",
                Email = "madina.n@kmg.kz",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("Pass123!"),
                Position = "Financial Analyst", Department = "Finance",
                HireDate = DateTime.UtcNow.AddDays(-30),
                OnboardingStatus = OnboardingStatus.OnTrack, OnboardingProgress = 68
            },
            new()
            {
                FirstName = "Arman", LastName = "Zhaksybekov",
                Email = "arman.z@kmg.kz",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("Pass123!"),
                Position = "Safety Engineer", Department = "HSE",
                HireDate = DateTime.UtcNow.AddDays(-5),
                OnboardingStatus = OnboardingStatus.InProgress, OnboardingProgress = 12
            },
            new()
            {
                FirstName = "Aliya", LastName = "Dzhaksybekova",
                Email = "aliya.d@kmg.kz",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("Pass123!"),
                Position = "IT Systems Analyst", Department = "Information Technology",
                HireDate = DateTime.UtcNow.AddDays(-45),
                OnboardingStatus = OnboardingStatus.AtRisk, OnboardingProgress = 28
            }
        };

            await db.Employees.AddAsync(hrManager);
            await db.Employees.AddRangeAsync(employees);

            var plan = new OnboardingPlan
            {
                Title = "Standard 90-Day Onboarding",
                Description = "Comprehensive onboarding for all new KMG employees",
                Department = "All",
                Position = "All",
                DurationDays = 90,
                IsTemplate = true,
                Tasks = new List<OnboardingTask>
            {
                new() { Title = "Complete employment paperwork", Description = "Sign contract and all required documents", Category = TaskCategory.Paperwork, DayNumber = 1, EstimatedMinutes = 120, Priority = 1, IsRequired = true },
                new() { Title = "HSE Safety Induction", Description = "Mandatory safety training for all KMG employees", Category = TaskCategory.SafetyCompliance, DayNumber = 1, EstimatedMinutes = 180, Priority = 1, IsRequired = true },
                new() { Title = "IT Systems Setup", Description = "Get corporate email, VPN, and system access", Category = TaskCategory.SystemAccess, DayNumber = 2, EstimatedMinutes = 90, Priority = 1, IsRequired = true },
                new() { Title = "Meet your direct manager", Description = "Introduction meeting with direct supervisor", Category = TaskCategory.TeamIntroduction, DayNumber = 3, EstimatedMinutes = 60, Priority = 2, IsRequired = true },
                new() { Title = "KMG Corporate Values Training", Description = "Learn about KMG mission, values, and culture", Category = TaskCategory.CorporateCulture, DayNumber = 5, EstimatedMinutes = 90, Priority = 2, IsRequired = true },
                new() { Title = "Department tour and introductions", Description = "Meet your immediate team and colleagues", Category = TaskCategory.TeamIntroduction, DayNumber = 5, EstimatedMinutes = 120, Priority = 2, IsRequired = false },
                new() { Title = "Review KMG Code of Conduct", Description = "Read and acknowledge the code of conduct policy", Category = TaskCategory.Paperwork, DayNumber = 7, EstimatedMinutes = 60, Priority = 2, IsRequired = true },
                new() { Title = "Complete mandatory e-learning modules", Description = "Anti-corruption, data privacy, and compliance training", Category = TaskCategory.Training, DayNumber = 14, EstimatedMinutes = 240, Priority = 1, IsRequired = true },
                new() { Title = "Benefits enrollment", Description = "Sign up for health insurance and other benefits", Category = TaskCategory.Paperwork, DayNumber = 14, EstimatedMinutes = 45, Priority = 2, IsRequired = true },
                new() { Title = "Shadow a senior team member", Description = "Job shadowing to understand daily workflows", Category = TaskCategory.KnowledgeBase, DayNumber = 21, EstimatedMinutes = 480, Priority = 2, IsRequired = false },
                new() { Title = "First performance goal-setting", Description = "Set 90-day goals with your manager", Category = TaskCategory.KnowledgeBase, DayNumber = 30, EstimatedMinutes = 60, Priority = 1, IsRequired = true },
                new() { Title = "Advanced technical training", Description = "Role-specific technical skills development", Category = TaskCategory.Training, DayNumber = 45, EstimatedMinutes = 360, Priority = 2, IsRequired = false }
            }
            };

            await db.OnboardingPlans.AddAsync(plan);

            var generalRoom = new ChatRoom
            {
                Name = "General",
                Description = "Company-wide announcements and discussions",
                RoomType = RoomType.General,
                Members = new List<ChatRoomMember>()
            };

            var onboardingRoom = new ChatRoom
            {
                Name = "New Employees",
                Description = "Support channel for all new hires",
                RoomType = RoomType.Onboarding,
                Members = new List<ChatRoomMember>()
            };

            await db.ChatRooms.AddRangeAsync(generalRoom, onboardingRoom);
            await db.SaveChangesAsync();

            var allEmployeeIds = new[] { hrManager.Id }.Concat(employees.Select(e => e.Id));
            foreach (var empId in allEmployeeIds)
            {
                generalRoom.Members.Add(new ChatRoomMember { RoomId = generalRoom.Id, EmployeeId = empId });
                onboardingRoom.Members.Add(new ChatRoomMember { RoomId = onboardingRoom.Id, EmployeeId = empId });
            }

            await db.ChatRoomMembers.AddRangeAsync(generalRoom.Members);
            await db.ChatRoomMembers.AddRangeAsync(onboardingRoom.Members);

            await db.ChatMessages.AddAsync(new ChatMessage
            {
                RoomId = generalRoom.Id,
                SenderId = hrManager.Id,
                Content = "Welcome to the KMG Onboarding Platform! This is your central hub for everything you need during your first 90 days. Don't hesitate to ask questions here.",
                MessageType = MessageType.Text
            });

            await db.SaveChangesAsync();
        }
    }
}
